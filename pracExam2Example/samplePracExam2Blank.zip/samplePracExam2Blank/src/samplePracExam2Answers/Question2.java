package samplePracExam2Answers;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;

 
//20 marks
class Waterbottle {
	public int capacity;
	public double price;

	/**
	 * IMPORTANT: DO NOT MODIFY!!!
	 * Parameterized Constructor: assigns parameters to corresponding instance variables
	 * @param c: value intended for capacity
	 * @param p: value intended for price
	 *
	 * assign the value of c into instance variable capacity if c >=0 and c <= 1000,
	 * else capacity = 0
	 * assign the value of p into instance variable price if p>=0 and p <= 10.55,
	 * else price = 0
	 */
	public Waterbottle(int c, double p) {
		capacity = c;
		if(c<0 || c > 1000) {
			capacity = 0;
		}
		price = p;
		if(p<0 || p > 10.55) {
			price = 0;
		}
	}

	/**
	 *
	 * Assume capacity is measured in milliliters (ml)
	 * @return total cost per ml for this Waterbottle, calculated 
	 * as the price divided by the capacity
	 * example,
	 * if price = 5
	 * and capacity = 10
	 * return 0.5
	 */
	public double getTotalCostPerMl() {
		return 0; //to be completed
	}

	/**
	 *
	 * @param other
	 * @return
	 * 1 if price of calling object is more than the price of the parameter object
	 * -1 if price of calling object is less than the price of the parameter object
	 * 0 if price of calling object is same as the price of the parameter object
	 */
	public int compareTo(Waterbottle other) {
		return 0; //to be completed
	}
	
} //end of class (do not delete this closing bracket)
    //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

public class Question2 { //begin TEST class 

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));


	@Test @Graded(description="Waterbottle::getTotalCostPerMl()", marks=10)
	public void testWaterbottleGetTotalCostPerMl() {
		Waterbottle j = new Waterbottle(20, 5);
		assertEquals(0.25, j.getTotalCostPerMl(), 0.01);

		j = new Waterbottle(1, 24.5);
		assertEquals(0, j.getTotalCostPerMl(), 0.01);

		j = new Waterbottle(2, 10);
		assertEquals(5, j.getTotalCostPerMl(), 0.01);

	}

	@Test @Graded(description="Waterbottle::compareTo(Waterbottle)", marks=10)
	public void testWaterbottleCompareToWaterbottle() {
		Waterbottle j1 = new Waterbottle(1000, 5.9);
		Waterbottle j2 = new Waterbottle(20, 3.6);
		Waterbottle j3 = new Waterbottle(21, 5.9);

		//NOTE: comparison is based on price
		assertEquals(1, j1.compareTo(j2));
		assertEquals(-1, j2.compareTo(j3));
		assertEquals(0, j3.compareTo(j1));

	}
} //end TEST class Question2 (do not delete this closing bracket)

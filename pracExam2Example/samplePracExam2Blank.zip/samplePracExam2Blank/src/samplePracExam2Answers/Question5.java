package samplePracExam2Answers;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question5 { //begin class 
	/**
	* @param arr
	* @param max
	* @return the count of all items in arr between index 0 and max that are non-negative
	* (inclusive of item at max)
	* return 0 if max < 0
	* You may assume arr is not null and contains at least 1 item and max is a valid index
	* IMPORTANT: must be solved recursively, that is by calling the method
	* itself in a way that it contributes to the final answer
	*/
	public static int countNonNegativeInArr(int[] arr, int max) {
		
		return 0; //to be completed
		
	} //end of sumBetweenRecursive (do not delete this closing bracket)
  //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="countNonNegativeInArr(int[], int)", marks=10)
	public void testCountNonNegativeInArr() {
		int[] a = {-3, 0, 4, 0, 5, 9, -8};
		int[] b = {-3};
		int[] c = {0};
		int[] d = {3};
		int[] e = {0,0,4,5};
		int[] f = {-3, -2, -1, 0};
		int[] g = {-3, 0, 4, 0, 5, 9, -8};
		assertEquals(5, Question5.countNonNegativeInArr(a, 5));
		assertEquals(0, Question5.countNonNegativeInArr(b, 0));
		assertEquals(1, Question5.countNonNegativeInArr(c, 0));
		assertEquals(1, Question5.countNonNegativeInArr(d, 0));
		assertEquals(3, Question5.countNonNegativeInArr(e, 2));
		assertEquals(1, Question5.countNonNegativeInArr(f, 3));
		assertEquals(2, Question5.countNonNegativeInArr(g, 2));

	}
} //end class (do not delete this closing bracket)


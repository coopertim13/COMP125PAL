package samplePracExam2Answers;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;

 
//10 marks
public class Question3 { //begin class 
	 /**
	 * @param data (assumed to not be null)
	 * @return count of items in data that are divisible by 5
	 */
	public static int countDivisibleBy5(int[] data) {
		
		return 0; //to be completed
		
	} //end of countDivisibleBy5 (do not delete this closing bracket)
    //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="countDivisibleBy5(int[])", marks=10)
	public void testCountDivisibleBy5() {
		int[] em = {};
		assertEquals(0, Question3.countDivisibleBy5(em));
		
		int[] a = {-4,-3,-2,-1};
		assertEquals(0, Question3.countDivisibleBy5(a));

		int[] b = {-5,-6,-7,-8};
		assertEquals(1, Question3.countDivisibleBy5(b));

		int[] c = {-7,5,-9,6};
		assertEquals(1, Question3.countDivisibleBy5(c));

		int[] d = {5, 10, 15, 24, 20, 25, 9, 43, 55};
		assertEquals(6, Question3.countDivisibleBy5(d));

		int[] e = {-5, -10, -15, -24, -20, -25, -9, -43, 55};
		assertEquals(6, Question3.countDivisibleBy5(e));

	}
} //end class (do not delete this closing bracket)

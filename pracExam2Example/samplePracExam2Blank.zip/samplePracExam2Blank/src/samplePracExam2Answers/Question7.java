package samplePracExam2Answers;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;

import java.lang.reflect.*;


//10 marks
class BookingSystem { //begin class 
	public Date checkIn;
	public Date checkOut;
	
	/**
	 * DEFAULT CONSTRUCTOR - DO NOT MODIFY!!!
	 */
	public BookingSystem() {
		this.checkIn = new Date(6, 9, 2019); //set checkIn to 6/9/2019
		this.checkOut = new Date(10, 9, 2019); //set checkOut to 10/9/2019
	}
	
	/**
	 * @param in: value intended for checkIn
	 * checkIn should be set to the earlier between 8/9/2019 and in
	 * @param out: value intended for checkOut
	 * checkOut should be set to the later between 12/9/2019 and out
	 * 
	 * * ***HINT*** you can use Date's compareTo method
	 */
	public BookingSystem(Date in, Date out) {
		this.checkIn = new Date(0, 0, 0); //to be completed
		this.checkOut = new Date(0, 0, 0); //to be completed
	}
	
} //end of class (do not delete this closing bracket)

public class Question7 { //begin class 
  //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="BookingSystem(Date, Date)", marks=10)
	public void testBookingSystem() {
		BookingSystem a = new BookingSystem(new Date(8,9,2019), new Date(12,9,2019));
		assertEquals("8/9/2019", Date.toString(a.checkIn));
		assertEquals("12/9/2019", Date.toString(a.checkOut));
		
		BookingSystem b = new BookingSystem(new Date(19,9,2019), new Date(20,9,2019));
		assertEquals("8/9/2019", Date.toString(b.checkIn));
		assertEquals("20/9/2019", Date.toString(b.checkOut));
		
		BookingSystem c = new BookingSystem(new Date(4,9,2019), new Date(12,9,2019));
		assertEquals("4/9/2019", Date.toString(c.checkIn));
		assertEquals("12/9/2019", Date.toString(c.checkOut));
		
		BookingSystem d = new BookingSystem(new Date(8,9,2019), new Date(30,9,2019));
		assertEquals("8/9/2019", Date.toString(d.checkIn));
		assertEquals("30/9/2019", Date.toString(d.checkOut));
		
		BookingSystem e = new BookingSystem(new Date(8,9,2019), new Date(9,9,2019));
		assertEquals("8/9/2019", Date.toString(e.checkIn));
		assertEquals("12/9/2019", Date.toString(e.checkOut));
		
		BookingSystem f = new BookingSystem(new Date(8,9,2015), new Date(17,10,2017));
		assertEquals("8/9/2015", Date.toString(f.checkIn));
		assertEquals("12/9/2019", Date.toString(f.checkOut));
		
		BookingSystem g = new BookingSystem(new Date(1,1,2020), new Date(1,1,2021));
		assertEquals("8/9/2019", Date.toString(g.checkIn));
		assertEquals("1/1/2021", Date.toString(g.checkOut));
	}
} //end class (do not delete this closing bracket)

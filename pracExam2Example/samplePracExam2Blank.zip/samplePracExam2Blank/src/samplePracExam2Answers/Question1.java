package samplePracExam2Answers;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;

 
//10 marks
class Banana {
	public double weight, length;

	/**
	 * DEFAULT CONSTRUCTOR - DO NOT MODIFY!!!
	 */
	public Banana() {
		weight = 1;
		length = 1;
	}

	/**
	* @param w: value to be copied into instance variable weight
	 * @param l: value to be copied into instance variable length
	 * set both instance variables to the higher between 1 and the corresponding parameter
	 * for example,
	 * if w = 2.5, weight should become 2.5
	 * if w = 0.0, weight should become 1.0
	 * if l = 1.4, length should become 1.4
	 * if l = -1.4, length should become 1.0
	 */
	public Banana(double w, double l) {
		//to be completed
	}
	
} //end of class (do not delete this closing bracket)
    //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

public class Question1 { //begin TEST class 

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));


	@Test @Graded(description="Banana(double, double)", marks=10)
	public void testBananaDoubleDouble() {
		Banana b = new Banana(1.2, 2.5);
		assertEquals(1.2, b.weight, 0.01);
		assertEquals(2.5, b.length, 0.01);

		b = new Banana(-1.5, -2.1);
		assertEquals(1, b.weight, 0.01);
		assertEquals(1, b.length, 0.01);

		b = new Banana(1.2, -2.4);
		assertEquals(1.2, b.weight, 0.01);
		assertEquals(1, b.length, 0.01);

		b = new Banana(-1.1, 2.5);
		assertEquals(1, b.weight, 0.01);
		assertEquals(2.5, b.length, 0.01);

	}
} //end TEST class Question1 (do not delete this closing bracket)

package samplePracExam2Answers;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question4 { //begin class 
	/**
	 * @param data
	 * @param divisor
	 * @return index of the last value in array that is DIVISIBLE BY divisor
	 *
	 * IMPORTANT: return -1 if array is null or if none of the items of the array are
	 * divisible by divisor
	 */
	public static int lastIndexDivisibleByDivisor(int[] data, int divisor) {
		
		return 0; //to be completed
		
	} //end of method lastIndexDivisibleByDivisor (do not delete this closing bracket)
  //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="lastIndexDivisibleByDivisor(int[], int)", marks=10)
	public void testLastIndexDivisibleByDivisor() {
		assertEquals(-1, Question4.lastIndexDivisibleByDivisor(null, 3298));
		int[] a = {1,6,2,9};
		assertEquals(3, Question4.lastIndexDivisibleByDivisor(a, 3));
		assertEquals(1, Question4.lastIndexDivisibleByDivisor(a, 6));
		assertEquals(2, Question4.lastIndexDivisibleByDivisor(a, 2));
		assertEquals(-1, Question4.lastIndexDivisibleByDivisor(a, 18));

	}
} //end class (do not delete this closing bracket)


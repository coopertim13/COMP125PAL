package samplePracExam2Answers;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question6 { //begin class 
	/**D QUESTION (made this one a little harder)
	* @param arr
	* @param min
	* @return the sum of all items in arr that are a perfect square
	* You may use the function checkPerfectSquare(int x) provided
	* You may assume arr is not null and contains at least 1 item and min is a valid index
	* IMPORTANT: must be solved recursively, that is by calling the method
	* itself in a way that it contributes to the final answer
	*/
	public static int sumPerfectSquaresInArr(int[] arr) {
		
		return 0; //to be completed
		
	} //end of sumPerfectSquaresInArr (do not delete this closing bracket)
	
	public static boolean checkPerfectSquare(int x) { 
		double sq = Math.sqrt(x); 
		return ((sq - Math.floor(sq)) == 0); 
    } //end of checkPerfectSquare (do not delete this closing bracket)
  //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="sumPerfectSquaresInArr(int[])", marks=10)
	public void testSumPerfectSquaresInArr() {
		int[] a = {-3, 0, 4, 0, 5, 9, -8};
		int[] b = {-4};
		int[] c = {0};
		int[] d = {225};
		int[] e = {0,0,4,5};
		int[] f = {144, 100, 65, 69};
		int[] g = {144, 65, 100, 69};
		assertEquals(13, Question6.sumPerfectSquaresInArr(a));
		assertEquals(0, Question6.sumPerfectSquaresInArr(b));
		assertEquals(0, Question6.sumPerfectSquaresInArr(c));
		assertEquals(225, Question6.sumPerfectSquaresInArr(d));
		assertEquals(4, Question6.sumPerfectSquaresInArr(e));
		assertEquals(244, Question6.sumPerfectSquaresInArr(f));
		assertEquals(244, Question6.sumPerfectSquaresInArr(g));

	}
} //end class (do not delete this closing bracket)


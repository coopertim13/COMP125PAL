package samplePracExam2Answers;

//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;

//10 marks
public class Question8 { //begin class 
	/**
	 * @param arr: an array of integers
	 * @param min
	 * @return a count of the number of ways any 2 integers THAT ARE NOT NEXT TO EACH OTHER
	 * from arr can be added so its total is >= min
	 *
	 * For example, if arr is [1,2,1,3,4,8], and min = 7
	 * method should return 4 because
	 * (1,8), (2,8), (1,8), (3,8)
	 * are all the possible ways 2 items from arr can be added, where its total is >= min
	 * and the two numbers are not next to each other in arr
	 * Although (3,4) and (4,8) add to >= min, the numbers are next to each other in arr,
	 * so they are not counted in the count
	 * 
	 * Note that (1,8) is there twice - this is because the method references
	 * two different '1' items (at index 0 AND index 2)
	 * 
	 * Note also that (2,8) is the same as (8,2) -> but you should only count it once
	 *
	 * You may add a helper method if you need one
	 */
	public static int countComboOfTwo(int[] arr, int min) {
		
		return 0; //to be completed
		
	} //end of method countComboOfTwo (do not delete this closing bracket)
  //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="countComboOfTwo(int[], int)", marks=10)
	public void testCountComboOfTwo() {
		int[] a = {1,2,1,3,4,8};
		assertEquals(4, Question8.countComboOfTwo(a, 7));
		assertEquals(0, Question8.countComboOfTwo(null, 2390));
		a = new int[] {1};
		assertEquals(0, Question8.countComboOfTwo(a, 290));
		a = new int[] {1, 90};
		assertEquals(0, Question8.countComboOfTwo(a, 91));
		a = new int[] {1, 90, 80};
		assertEquals(1, Question8.countComboOfTwo(a, 4));
		a = new int[] {-39, 28, 100, 56, -4, 0, 9};
		assertEquals(6, Question8.countComboOfTwo(a, 61));
	}
} //end class (do not delete this closing bracket)


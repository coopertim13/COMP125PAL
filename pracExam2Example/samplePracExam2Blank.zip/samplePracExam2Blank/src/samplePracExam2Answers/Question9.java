package samplePracExam2Answers;

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;

import java.lang.reflect.*;

public class Question9 {
	/**
	* @param arr
	* @param i
	* @param k
	* @return the total number of combinations of k length in arr
	* A combination is a selection of items from a collection, such that 
	* the order of selection does not matter
	* Assume k >=1 and is valid
	* 
    * examples:
	* if data = {1,2,3,4} and k = 3, return 4 as there are 4 combinations of length 3
	* COMBINATIONS: {1,2,3}, {1,2,4}, {1,3,4}, {2,3,4}
	* 
	* if data = {1,2,3,4} and k = 2, return 6 as there are 6 combinations of length 2
	* COMBINATIONS: {1,2}, {1,3}, {1,4}, {2,3}, {2,4}, {3,4}
	*
	* Scroll to underneath the question for a hint
	* 
	* IMPORTANT: must be solved recursively, that is by calling the method
	* itself in a way that it contributes to the final answer
	*/
	public static int combinations(int[] arr, int i, int k) {
		
		return 0; //to be completed
		
	} //end of combinations (do not delete this closing bracket)
	/**
	* HINT (will help understand program logic)
	* If we know k = 3, to find the number of combinations in arr our method would look
	* like this:
	* 
	* int count = 0;
	* for(int i = 0; i < arr.length; i++) {
	* 	for(int j = i+1; j < arr.length; j++) {
	* 		for(int k = j+1; k < arr.length; k++) {
	* 			count++;
	* 		}
	* 	}
	* }
	* return count;
	* 
	* The important note to get from this example is that if we are looking for the number
	* of combinations of k length, we need k nested loops formatted just like the above
	**/
    //IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!
	
	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="combinations(int[], int, int)", marks=10)
	public void testCombinations() {
		assertEquals(2, Question9.combinations(new int[]{2,3}, 0, 1));
		assertEquals(1, Question9.combinations(new int[]{2,3}, 0, 2));
		assertEquals(1, Question9.combinations(new int[]{-2, -3}, 0, 2));
		assertEquals(2, Question9.combinations(new int[]{0, 0}, 0, 1));
		assertEquals(21, Question9.combinations(new int[]{9, 3, 2, -4, 0, 6, 6}, 0, 5));
		assertEquals(0, Question9.combinations(new int[]{}, 0, 1));
		assertEquals(0, Question9.combinations(new int[]{}, 0, 5));
	}
}

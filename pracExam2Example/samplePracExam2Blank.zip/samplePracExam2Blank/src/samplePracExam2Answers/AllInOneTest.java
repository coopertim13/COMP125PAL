package samplePracExam2Answers;
/*****************************
*                           *
* DO NOT MODIFY THIS FILE   *
*						 	 *
*****************************/

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;

import samplePracExam2Answers.Date;

import java.lang.reflect.*;

public class AllInOneTest {
  public static String currentMethodName = null;
  public static int score = 0;
  public static String result = "";

  @Before
  public void beforeEachTest() {
    currentMethodName = null;
  }
  
  @SuppressWarnings("deprecation")
  @Rule
  public TestRule timeout = new DisableOnDebug(new Timeout(1000));

  @Test @Graded(description="Banana(double, double)", marks=10)
	public void testBananaDoubleDouble() {
		Banana b = new Banana(1.2, 2.5);
		assertEquals(1.2, b.weight, 0.01);
		assertEquals(2.5, b.length, 0.01);

		b = new Banana(-1.5, -2.1);
		assertEquals(1, b.weight, 0.01);
		assertEquals(1, b.length, 0.01);

		b = new Banana(1.2, -2.4);
		assertEquals(1.2, b.weight, 0.01);
		assertEquals(1, b.length, 0.01);

		b = new Banana(-1.1, 2.5);
		assertEquals(1, b.weight, 0.01);
		assertEquals(2.5, b.length, 0.01);

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}



  @Test @Graded(description="Waterbottle::getTotalCostPerMl()", marks=10)
	public void testWaterbottleGetTotalCostPerMl() {
		Waterbottle j = new Waterbottle(20, 5);
		assertEquals(0.25, j.getTotalCostPerMl(), 0.01);

		j = new Waterbottle(1, 24.5);
		assertEquals(0, j.getTotalCostPerMl(), 0.01);

		j = new Waterbottle(2, 10);
		assertEquals(5, j.getTotalCostPerMl(), 0.01);
		
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();

	}

	@Test @Graded(description="Waterbottle::compareTo(Waterbottle)", marks=10)
	public void testWaterbottleCompareToWaterbottle() {
		Waterbottle j1 = new Waterbottle(1000, 5.9);
		Waterbottle j2 = new Waterbottle(20, 3.6);
		Waterbottle j3 = new Waterbottle(21, 5.9);

		//NOTE: comparison is based on price
		assertEquals(1, j1.compareTo(j2));
		assertEquals(-1, j2.compareTo(j3));
		assertEquals(0, j3.compareTo(j1));
		
		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();

	}


	@Test @Graded(description="countDivisibleBy5(int[])", marks=10)
	public void testCountDivisibleBy5() {
		int[] em = {};
		assertEquals(0, Question3.countDivisibleBy5(em));
		
		int[] a = {-4,-3,-2,-1};
		assertEquals(0, Question3.countDivisibleBy5(a));

		int[] b = {-5,-6,-7,-8};
		assertEquals(1, Question3.countDivisibleBy5(b));

		int[] c = {-7,5,-9,6};
		assertEquals(1, Question3.countDivisibleBy5(c));

		int[] d = {5, 10, 15, 24, 20, 25, 9, 43, 55};
		assertEquals(6, Question3.countDivisibleBy5(d));

		int[] e = {-5, -10, -15, -24, -20, -25, -9, -43, 55};
		assertEquals(6, Question3.countDivisibleBy5(e));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


	@Test @Graded(description="lastIndexDivisibleByDivisor(int[], int)", marks=10)
	public void testLastIndexDivisibleByDivisor() {
		assertEquals(-1, Question4.lastIndexDivisibleByDivisor(null, 3298));
		int[] a = {1,6,2,9};
		assertEquals(3, Question4.lastIndexDivisibleByDivisor(a, 3));
		assertEquals(1, Question4.lastIndexDivisibleByDivisor(a, 6));
		assertEquals(2, Question4.lastIndexDivisibleByDivisor(a, 2));
		assertEquals(-1, Question4.lastIndexDivisibleByDivisor(a, 18));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


	@Test @Graded(description="countNonNegativeInArr(int[], int)", marks=10)
	public void testCountNonNegativeInArr() {
		int[] a = {-3, 0, 4, 0, 5, 9, -8};
		int[] b = {-3};
		int[] c = {0};
		int[] d = {3};
		int[] e = {0,0,4,5};
		int[] f = {-3, -2, -1, 0};
		int[] g = {-3, 0, 4, 0, 5, 9, -8};
		assertEquals(5, Question5.countNonNegativeInArr(a, 5));
		assertEquals(0, Question5.countNonNegativeInArr(b, 0));
		assertEquals(1, Question5.countNonNegativeInArr(c, 0));
		assertEquals(1, Question5.countNonNegativeInArr(d, 0));
		assertEquals(3, Question5.countNonNegativeInArr(e, 2));
		assertEquals(1, Question5.countNonNegativeInArr(f, 3));
		assertEquals(2, Question5.countNonNegativeInArr(g, 2));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


	@Test @Graded(description="sumPerfectSquaresInArr(int[])", marks=10)
	public void testSumPerfectSquaresInArr() {
		int[] a = {-3, 0, 4, 0, 5, 9, -8};
		int[] b = {-4};
		int[] c = {0};
		int[] d = {225};
		int[] e = {0,0,4,5};
		int[] f = {144, 100, 65, 69};
		int[] g = {144, 65, 100, 69};
		assertEquals(13, Question6.sumPerfectSquaresInArr(a));
		assertEquals(0, Question6.sumPerfectSquaresInArr(b));
		assertEquals(0, Question6.sumPerfectSquaresInArr(c));
		assertEquals(225, Question6.sumPerfectSquaresInArr(d));
		assertEquals(4, Question6.sumPerfectSquaresInArr(e));
		assertEquals(244, Question6.sumPerfectSquaresInArr(f));
		assertEquals(244, Question6.sumPerfectSquaresInArr(g));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


	@Test @Graded(description="BookingSystem(Date, Date)", marks=10)
	public void testBookingSystem() {
		BookingSystem a = new BookingSystem(new Date(8,9,2019), new Date(12,9,2019));
		assertEquals("8/9/2019", Date.toString(a.checkIn));
		assertEquals("12/9/2019", Date.toString(a.checkOut));
		
		BookingSystem b = new BookingSystem(new Date(19,9,2019), new Date(20,9,2019));
		assertEquals("8/9/2019", Date.toString(b.checkIn));
		assertEquals("20/9/2019", Date.toString(b.checkOut));
		
		BookingSystem c = new BookingSystem(new Date(4,9,2019), new Date(12,9,2019));
		assertEquals("4/9/2019", Date.toString(c.checkIn));
		assertEquals("12/9/2019", Date.toString(c.checkOut));
		
		BookingSystem d = new BookingSystem(new Date(8,9,2019), new Date(30,9,2019));
		assertEquals("8/9/2019", Date.toString(d.checkIn));
		assertEquals("30/9/2019", Date.toString(d.checkOut));
		
		BookingSystem e = new BookingSystem(new Date(8,9,2019), new Date(9,9,2019));
		assertEquals("8/9/2019", Date.toString(e.checkIn));
		assertEquals("12/9/2019", Date.toString(e.checkOut));
		
		BookingSystem f = new BookingSystem(new Date(8,9,2015), new Date(17,10,2017));
		assertEquals("8/9/2015", Date.toString(f.checkIn));
		assertEquals("12/9/2019", Date.toString(f.checkOut));
		
		BookingSystem g = new BookingSystem(new Date(1,1,2020), new Date(1,1,2021));
		assertEquals("8/9/2019", Date.toString(g.checkIn));
		assertEquals("1/1/2021", Date.toString(g.checkOut));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


	@Test @Graded(description="countComboOfTwo(int[], int)", marks=10)
	public void testCountComboOfTwo() {
		int[] a = {1,2,1,3,4,8};
		assertEquals(4, Question8.countComboOfTwo(a, 7));
		assertEquals(0, Question8.countComboOfTwo(null, 2390));
		a = new int[] {1};
		assertEquals(0, Question8.countComboOfTwo(a, 290));
		a = new int[] {1, 90};
		assertEquals(0, Question8.countComboOfTwo(a, 91));
		a = new int[] {1, 90, 80};
		assertEquals(1, Question8.countComboOfTwo(a, 4));
		a = new int[] {-39, 28, 100, 56, -4, 0, 9};
		assertEquals(6, Question8.countComboOfTwo(a, 61));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


	@Test @Graded(description="combinations(int[], int, int)", marks=10)
	public void testCombinations() {
		assertEquals(2, Question9.combinations(new int[]{2,3}, 0, 1));
		assertEquals(1, Question9.combinations(new int[]{2,3}, 0, 2));
		assertEquals(1, Question9.combinations(new int[]{-2, -3}, 0, 2));
		assertEquals(2, Question9.combinations(new int[]{0, 0}, 0, 1));
		assertEquals(21, Question9.combinations(new int[]{9, 3, 2, -4, 0, 6, 6}, 0, 5));
		assertEquals(0, Question9.combinations(new int[]{}, 0, 1));
		assertEquals(0, Question9.combinations(new int[]{}, 0, 5));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}



	@After
	public void logSuccess() throws NoSuchMethodException, SecurityException {
		if(currentMethodName != null) {
			Method method = getClass().getMethod(currentMethodName);
			Graded graded = method.getAnnotation(Graded.class);
			score+=graded.marks();
			result+=graded.description()+" passed. Marks awarded: "+graded.marks()+"\n";
		}
	}

	@AfterClass
	public static void wrapUp() throws IOException {
	System.out.println("Score = "+score);
		System.out.println(result);
	}
}

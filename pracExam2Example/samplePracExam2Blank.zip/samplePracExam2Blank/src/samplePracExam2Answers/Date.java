package samplePracExam2Answers;

public class Date {
	private int day;
	private int month;
	private int year;
	
	public Date(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	public int getDay() {
		return this.day;
	}
	
	public int getMonth() {
		return this.month;
	}
	
	public int getYear() {
		return this.year;
	}
	
	/**
	 * 
	 * @param other
	 * @return 	 1 if calling object comes after parameter object
	 * 			-1 if calling object comes before parameter object
	 * 			 0 if calling object and parameter object are the same
	 */
	public int compareTo(Date other) {
		if(this.year > other.year) {
			return 1;
		}
		else if(this.year < other.year) {
			return -1;
		}
		else {
			if(this.month > other.month) {
				return 1;
			}
			else if(this.month < other.month) {
				return -1;
			}
			else {
				if(this.day > other.day) {
					return 1;
				}
				else if(this.day < other.day) {
					return -1;
				}
				return 0;
			}
		}
	}
	
	/**
	 * DO NOT MODIFY
	 * USED FOR AUTOMARKER
	 */
	public static String toString(Date date) {
		return date.day + "/" + date.month + "/" + date.year;
	}
}

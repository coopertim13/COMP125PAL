package samplePracticalExam3;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question4 { //begin class 
	/**
	 * 
	 * @param str: assume it's not null
	 * @return string without vowels (a,e,i,o,u)
	 * for example,
	 * if str = "hello", return "hll"
	 * if str = "!", return "!"
	 * if str = "", return ""
	 * IMPLEMENTATION MUST BE RECURSIVE
	 * DO NOT CALL ANY OTHER METHOD (NO HELPERS ALLOWED)
	 */
	public static String removeVowelsRecursive(String str) {
		return ""; //to be completed
	}
	//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="removeVowelsRecursive(String)", marks=10)
	public void testRemoveVowelsRecursive() throws NoSuchMethodException, SecurityException {
		assertEquals("vl", Question4.removeVowelsRecursive("voila"));
		assertEquals("c", Question4.removeVowelsRecursive("c"));
		assertEquals("", Question4.removeVowelsRecursive(""));
		assertEquals("vl!", Question4.removeVowelsRecursive("voila!"));
		assertEquals("xf .rm ctstnf ht", Question4.removeVowelsRecursive("xof .rm citsatnaf eht"));

	}
} //end class (do not delete this closing bracket)

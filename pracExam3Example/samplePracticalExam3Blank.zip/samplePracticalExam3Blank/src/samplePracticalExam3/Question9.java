package samplePracticalExam3;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question9 { //begin class 
	/**
	 * @param start: starting index
	 * @param nums: array
	 * @param target
	 * @return true if it is possible (and false if not)
	 * to choose a group of some of the ints (starting at index start),
	 * such that the group multiplies to the
	 * given target with these additional constraints:
	 * All negative values must be included
	 * If the value immediately before the negative value is more than or equal to 10,
	 * that value must not be chosen
	 * 
	 * IMPLEMENTATION MUST BE RECURSIVE AND NO LOOPS SHOULD BE USED
	 *
	 * start = 0, nums = 5,1,2,4, target = 10 --> return true (5 * 2)
	 * start = 0, nums = 5,-1,3,2, target = -15 --> return true (5 * -1 * 3)
	 * start = 0, nums = 10,-1,-6,2, target = 60 --> return false
	 * 			(we cannot use 10 as it comes before a negative number)
	 * start = 0, nums = -5,-1,-10,-4, target = 200 --> return true
	 */
	public static boolean groupMultiplyNegativeRecursive(int start, int[] nums, double target) {
		return false; //to be completed
	}
	//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="groupMultiplyNegativeRecursive(int, int[], int)", marks=10)
	public void testGroupMultiplyNegativeRecursive() throws NoSuchMethodException, SecurityException {
		int[] a = {5,1,2,4};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, a, 10));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, a, 3));

		int[] b = {5,-1,3,2};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, b, -6));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, b, 15));

		int[] c = {5,-1,-6,2};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, c, 30));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, c, -30));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, c, -12));
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, c, 12));
		
		int[] d = {10,-1,-6,2};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, d, 6));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, d, 60));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, d, -12));
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, d, 12));

		int[] empty = {};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, empty, 1));

	}
} //end class (do not delete this closing bracket)

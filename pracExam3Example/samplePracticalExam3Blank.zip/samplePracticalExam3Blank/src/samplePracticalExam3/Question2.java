package samplePracticalExam3;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question2 { //begin class 
	/**
	 * 
	 * @param n: assumed to be more than 0
	 * @return the number of digits in n
	 * you may assume that 0 itself doesn't contain ANY digit (not even 0)
	 * hint: n%10 gives the last digit, n/10 gives the rest of the number
	 * IMPLEMENTATION MUST BE RECURSIVE
	 * DO NOT CALL ANY OTHER METHOD (NO HELPERS ALLOWED)
	 */
	public static int countNumberOfDigitsRecursive(int n) {
		return 0; //to be completed
	}
	//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="countNumberOfDigitsRecursive(int)", marks=10)
	public void testCountNumberOfDigitsRecursive() throws NoSuchMethodException, SecurityException {
		assertEquals(4, Question2.countNumberOfDigitsRecursive(1729));
		assertEquals(0, Question2.countNumberOfDigitsRecursive(0));
		assertEquals(1, Question2.countNumberOfDigitsRecursive(-9));
		assertEquals(3, Question2.countNumberOfDigitsRecursive(-729));

	}
} //end class (do not delete this closing bracket)

package samplePracticalExam3;

//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question1 { //begin class 
	/**
	 *
	 * @param list
	 * @return true if all of the values in list are odd, false otherwise
	 * return false if list is null or empty
	 */
	public static boolean allOdd(ArrayList<Integer> list) {
		return false; //to be completed
	}
	//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="testAllOddArrayList(ArrayList<Integer>)", marks=10)
	public void testAllOddArrayList() throws NoSuchMethodException, SecurityException {
		assertFalse(Question1.allOdd(null));

		ArrayList<Integer> emptyList = new ArrayList<Integer>();
		assertFalse(Question1.allOdd(emptyList));

		ArrayList<Integer> list1 = new ArrayList<Integer>(Arrays.asList(6, 0, 5, -7, -10));
		assertFalse(Question1.allOdd(list1));

		ArrayList<Integer> list2 = new ArrayList<Integer>(Arrays.asList(0, -2, 2, 4, -4));
		assertFalse(Question1.allOdd(list2)); //all 5 values are even

		ArrayList<Integer> list3 = new ArrayList<Integer>(Arrays.asList(1, -1, 3, -3));
		assertTrue(Question1.allOdd(list3)); //none of the values are even

	}
} //end class (do not delete this closing bracket)


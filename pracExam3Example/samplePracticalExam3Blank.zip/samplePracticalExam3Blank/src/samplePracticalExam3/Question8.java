package samplePracticalExam3;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question8 { //begin class 
	/**
	 * @param list
	 * @return the list without the 2 integers that, when multiplied together, have
	 * the maximum product in EITHER direction (positive or negative)
	 * if there is a tie, return the list without the 2 integers that have the
	 * maximum POSITIVE product
	 * @return null if the list is null or empty or contains only 1 item
	 * 
	 * for example,
	 * if list = null or an empty list, return null
	 * if list = [6], return null
	 * 
	 * if list = [-6, 1, -4, 2, 8, -3, 9], return [-6, 1, -4, 2, -3]
	 * 		(8 * 9 = 72 results in maximum product out of all pairs of integers in list)
	 * 
	 * if list = [6, 1, -4, 2, 3, 4, -9], return [1, -4, 2, 3, 4]
	 * 		(-9 * 6 = -54 results in maximum product out of all pairs of integers in list)
	 * 
	 * if list = [6, -9, -6, 3, 2, -1], return [6, 3, 2, -1]
	 * 		(both (-9*-6 = 54) and (-9*6 = -54) are max, but in the case of a tie we do not
	 * 		 include the 2 integers with the max POSITIVE product)
	 *
	 * IMPORTANT: you should NOT modify the passed list
	 */
	public static ArrayList<Integer> listWithoutMaxProductPair(ArrayList<Integer> list) {
		return new ArrayList<Integer>(); //to be completed
	}
	
	//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(marks=10, description="listWithoutMaxProductPair(List)")
	public void testListWithoutMaxProductPairList() throws NoSuchMethodException, SecurityException {
		ArrayList<Integer> list = null;
		ArrayList<Integer> asc = Question8.listWithoutMaxProductPair(list);
		assertNull(asc);

		list = new ArrayList<Integer>();
		asc = Question8.listWithoutMaxProductPair(list);
		assertNull(asc);

		list.add(-3);
		asc = Question8.listWithoutMaxProductPair(list);
		assertNull(asc);
		
		list.add(2);
		asc = Question8.listWithoutMaxProductPair(list);
		assertTrue(asc.size() == 0);
		
		list.add(1);
		asc = Question8.listWithoutMaxProductPair(list);
		assertEquals("[1]", asc.toString());
		
		list.add(-6);
		list.add(-4);
		list.add(8);
		list.add(9);
		asc = Question8.listWithoutMaxProductPair(list);
		assertEquals("[-3, 2, 1, -6, -4]", asc.toString());
		
		ArrayList<Integer> list2 = new ArrayList<>();
		//6, 1, -4, 2, 3, 4, -9
		list2.add(6);
		list2.add(1);
		list2.add(-4);
		list2.add(2);
		list2.add(3);
		list2.add(4);
		list2.add(-9);
		asc = Question8.listWithoutMaxProductPair(list2);
		assertEquals("[1, -4, 2, 3, 4]", asc.toString());
		
		ArrayList<Integer> list3 = new ArrayList<>();
		//6, -9, -6, 3, 2, -1
		list3.add(6);
		list3.add(-9);
		list3.add(-6);
		list3.add(3);
		list3.add(2);
		list3.add(-1);
		asc = Question8.listWithoutMaxProductPair(list3);
		assertEquals("[6, 3, 2, -1]", asc.toString());

	}
} //end class (do not delete this closing bracket)

package samplePracticalExam3;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
//method add(int,int) at the bottom of the class must be completed
class MyArrayList {
	public int[] data;
	public final static int MAX_SIZE = 500;
	public final static int INC_SIZE = 5;
	public final static int DEFAULT_SIZE = 5;
	public int nItems;

	/**
	 * DO NOT MODIFY
	 * create a list with an initial size of DEFAULT_SIZE
	 */
	public MyArrayList() {
		data = new int[DEFAULT_SIZE];
		nItems = 0; //currently 0 items added to list
	}

	/**
	 * DO NOT MODIFY
	 * create a list with an initial size of n
	 * @param n
	 */
	public MyArrayList(int n) {
		if(n > 0 && n <= MAX_SIZE)
			data = new int[n];
		else
			data = new int[DEFAULT_SIZE];
		nItems = 0; //currently 0 items added to list
	}

	// DO NOT MODIFY
	public String toString() {
		String s = "List size "+nItems+": [";
		for(int i=0; i<nItems; i++)
			s+=data[i]+", ";
		if(data.length > 0)
			s = s.substring(0, s.length()-2);
		return s + "]";
	}

	// DO NOT MODIFY
	public void add(int item) {
		if(isFull()) //if full, reserve a bigger block
			grow();
		data[nItems] = item;
		nItems++; //next item should be inserted one index ahead
	}

	// DO NOT MODIFY
	public boolean isFull() {
		return nItems == data.length;
	}

	// DO NOT MODIFY
	public int indexOf(int item) {
		for(int i=0; i<nItems; i++)
			if(data[i] == item)
				return i;
		return -1;
	}

	/**
	 * DO NOT MODIFY
	 * @return number of items in the list
	 */
	public int size() {
		return nItems;
	}

	/**
	 * DO NOT MODIFY
	 * @return capacity of the list
	 */
	public int capacity() {
		return data.length;
	}

	/**
	 * DO NOT MODIFY
	 * @param idx: index from which the item should be returned
	 * @return null if index is invalid, otherwise the item at that index
	 */
	public Integer get(int idx) {
		if(idx < 0 || idx >= nItems)
			return null;
		return data[idx];
	}

	/**
	 * DO NOT MODIFY
	 * ONLY IF the array is full,
	 * increase the capacity of the array by INC_SIZE
	 * for example,
	 * if before calling the method,
	 * data = [2, 8, 3, 5, 7, 1, 4, 2, 5, 3] (nItems = 10, data.length = 10),
	 * then after the method call, it should become
	 * data = [2, 8, 3, 5, 7, 1, 4, 2, 5, 3, 0, 0, 0, 0, 0]
	 *
	 * if before calling the method,
	 * data = [2, 8, 3, 5, 7, 1, 4, 0, 0, 0] (nItems = 7, data.length = 10),
	 * then after the method call, it should STAY
	 * data = [2, 8, 3, 5, 7, 1, 4, 0, 0, 0]
	 */
	public void grow() {
		if(nItems < data.length) {
			return;
		}
		//create an array INC_SIZE items more than current array
		int[] temp = new int[data.length + INC_SIZE];

		//copy all items to new array
		for(int i=0; i<data.length; i++)
			temp[i] = data[i];

		//update the reference (java's garbage collection handles the old array)
		data = temp;
	}

	/**
	 *
	 * remove the middle item from data
	 * if the number of items is even, remove the the right middle item
	 * you may assume that data has >= 2 items
	 * for example,
	 * if before calling the method,
	 * data = [2, 8, 3, 5, 7, 1, 4, 2, 5, 3] (nItems = 10, data.length = 10, all items occupied),
	 * then after the method call, it should become
	 * data = [2, 8, 3, 5, 7, 4, 2, 5, 3, 0] (nItems = 9, data.length = 10, last item unoccupied),
	 *
	 * if before calling the method,
	 * data = [2, 8, 3, 5, 7, 1, 0, 0, 0, 0]
	 * 		(nItems = 6, data.length = 10, last four items unoccupied),
	 * then after the method call, it should become
	 * data = [2, 8, 3, 7, 1] (nItems = 5, data.length = 5, data is full)
	 */
	public void removeMiddleItem() {
		//to be completed
	}
}

//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

public class Question6 { //begin TEST class 

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="MyArrayList:removeMiddleItem()", marks=10)
	public void testMyArrayListRemoveMiddleItem() throws NoSuchMethodException, SecurityException {
		MyArrayList list = new MyArrayList(); //create list of default size (5)

		list.add(2);
		list.add(8);
		list.add(3);
		list.add(5);
		list.add(7);
		list.add(1);
		list.add(4);
		list.add(2);
		list.add(5);
		list.add(3);

		list.removeMiddleItem(); //2, 8, 3, 5, 7, 4, 2, 5, 3, 0
		assertFalse(list.isFull());
		assertTrue(list.get(0).compareTo(2)==0);
		assertTrue(list.get(1).compareTo(8)==0);
		assertTrue(list.get(2).compareTo(3)==0);
		assertTrue(list.get(3).compareTo(5)==0);
		assertTrue(list.get(4).compareTo(7)==0);
		assertTrue(list.get(5).compareTo(4)==0);
		assertTrue(list.get(6).compareTo(2)==0);
		assertTrue(list.get(7).compareTo(5)==0);
		assertTrue(list.get(8).compareTo(3)==0);
		assertNull(list.get(9));
		assertEquals(9, list.nItems);
		assertEquals(10, list.data.length);
		
		//-------------------------------------------------------
		
		MyArrayList list2 = new MyArrayList(); //create list of default size (5)

		list2.add(2);
		list2.add(8);
		list2.add(3);
		list2.add(5);
		list2.add(7);
		list2.add(1);
		
		list2.removeMiddleItem(); //2, 8, 3, 7, 1
		assertTrue(list2.isFull());
		assertTrue(list2.get(0).compareTo(2)==0);
		assertTrue(list2.get(1).compareTo(8)==0);
		assertTrue(list2.get(2).compareTo(3)==0);
		assertTrue(list2.get(3).compareTo(7)==0);
		assertTrue(list2.get(4).compareTo(1)==0);
		assertNull(list2.get(5));
		assertNull(list2.get(6));
		assertEquals(5, list2.nItems);
		assertEquals(5, list2.data.length);
		
	}
} //end TEST class Question6 (do not delete this closing bracket)

package samplePracticalExam3;
/*****************************
*                           *
* DO NOT MODIFY THIS FILE   *
*						 	 *
*****************************/

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;

public class AllInOneTest {
  public static String currentMethodName = null;
  public static int score = 0;
  public static String result = "";

  @Before
  public void beforeEachTest() {
    currentMethodName = null;
  }
  
  @SuppressWarnings("deprecation")
  @Rule
  public TestRule timeout = new DisableOnDebug(new Timeout(1000));
  @Test @Graded(description="testAllOddArrayList(ArrayList<Integer>)", marks=10)
	public void testAllOddArrayList() throws NoSuchMethodException, SecurityException {
		assertFalse(Question1.allOdd(null));

		ArrayList<Integer> emptyList = new ArrayList<Integer>();
		assertFalse(Question1.allOdd(emptyList));

		ArrayList<Integer> list1 = new ArrayList<Integer>(Arrays.asList(6, 0, 5, -7, -10));
		assertFalse(Question1.allOdd(list1));

		ArrayList<Integer> list2 = new ArrayList<Integer>(Arrays.asList(0, -2, 2, 4, -4));
		assertFalse(Question1.allOdd(list2)); //all 5 values are even

		ArrayList<Integer> list3 = new ArrayList<Integer>(Arrays.asList(1, -1, 3, -3));
		assertTrue(Question1.allOdd(list3)); //none of the values are even

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


  @Test @Graded(description="countNumberOfDigitsRecursive(int)", marks=10)
	public void testCountNumberOfDigitsRecursive() throws NoSuchMethodException, SecurityException {
		assertEquals(4, Question2.countNumberOfDigitsRecursive(1729));
		assertEquals(0, Question2.countNumberOfDigitsRecursive(0));
		assertEquals(1, Question2.countNumberOfDigitsRecursive(-9));
		assertEquals(3, Question2.countNumberOfDigitsRecursive(-729));


		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


  @Test @Graded(description="multiplicationBesidesX(ArrayList<Integer>, int)", marks=10)
	public void testMultiplicationBesidesX() throws NoSuchMethodException, SecurityException {
		assertEquals(-1, Question3.multiplicationBesidesX(null, 20)); //null list check
		ArrayList<Integer> list = new ArrayList<Integer>();
		assertEquals(-1, Question3.multiplicationBesidesX(list, -291)); //empty list check

		list.add(20);
		assertEquals(20, Question3.multiplicationBesidesX(list, 10));
		list.add(30);
		assertEquals(600, Question3.multiplicationBesidesX(list, -10));

		list.add(60);
		assertEquals(1200, Question3.multiplicationBesidesX(list, 30));

		list.add(10);
		list.add(50);
		list.add(30);
		assertEquals(10800000, Question3.multiplicationBesidesX(list, 50));


		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


  @Test @Graded(description="removeVowelsRecursive(String)", marks=10)
	public void testRemoveVowelsRecursive() throws NoSuchMethodException, SecurityException {
		assertEquals("vl", Question4.removeVowelsRecursive("voila"));
		assertEquals("c", Question4.removeVowelsRecursive("c"));
		assertEquals("", Question4.removeVowelsRecursive(""));
		assertEquals("vl!", Question4.removeVowelsRecursive("voila!"));
		assertEquals("xf .rm ctstnf ht", Question4.removeVowelsRecursive("xof .rm citsatnaf eht"));


		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


  @Test @Graded(description="addDoubleToEnd(ArrayList<Integer>)", marks=10)
	public void testAddDoubleToEndArrayList() throws NoSuchMethodException, SecurityException {
		ArrayList<Integer> list = new ArrayList<Integer>();

		list.add(-5);
		list.add(0);
		list.add(-7);
		list.add(3);
		list.add(-8);
		Question5.addDoubleToEnd(list);
		assertEquals("[-5, 0, -7, 3, -8, -10, 0, -14, 6, -16]", list.toString());


		ArrayList<Integer> list2 = new ArrayList<Integer>();
		list2.add(5);
		list2.add(-20);
		list2.add(-50);
		list2.add(7);
		list2.add(8);
		Question5.addDoubleToEnd(list2);
		assertEquals("[5, -20, -50, 7, 8, 10, -40, -100, 14, 16]", list2.toString());

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


  @Test @Graded(description="MyArrayList:removeMiddleItem()", marks=10)
	public void testMyArrayListRemoveMiddleItem() throws NoSuchMethodException, SecurityException {
		MyArrayList list = new MyArrayList(); //create list of default size (5)

		list.add(2);
		list.add(8);
		list.add(3);
		list.add(5);
		list.add(7);
		list.add(1);
		list.add(4);
		list.add(2);
		list.add(5);
		list.add(3);

		list.removeMiddleItem(); //2, 8, 3, 5, 7, 4, 2, 5, 3, 0
		assertFalse(list.isFull());
		assertTrue(list.get(0).compareTo(2)==0);
		assertTrue(list.get(1).compareTo(8)==0);
		assertTrue(list.get(2).compareTo(3)==0);
		assertTrue(list.get(3).compareTo(5)==0);
		assertTrue(list.get(4).compareTo(7)==0);
		assertTrue(list.get(5).compareTo(4)==0);
		assertTrue(list.get(6).compareTo(2)==0);
		assertTrue(list.get(7).compareTo(5)==0);
		assertTrue(list.get(8).compareTo(3)==0);
		assertNull(list.get(9));
		assertEquals(9, list.nItems);
		assertEquals(10, list.data.length);
		
		//-------------------------------------------------------
		
		MyArrayList list2 = new MyArrayList(); //create list of default size (5)

		list2.add(2);
		list2.add(8);
		list2.add(3);
		list2.add(5);
		list2.add(7);
		list2.add(1);
		
		list2.removeMiddleItem(); //2, 8, 3, 7, 1
		assertTrue(list2.isFull());
		assertTrue(list2.get(0).compareTo(2)==0);
		assertTrue(list2.get(1).compareTo(8)==0);
		assertTrue(list2.get(2).compareTo(3)==0);
		assertTrue(list2.get(3).compareTo(7)==0);
		assertTrue(list2.get(4).compareTo(1)==0);
		assertNull(list2.get(5));
		assertNull(list2.get(6));
		assertEquals(5, list2.nItems);
		assertEquals(5, list2.data.length);

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


  @Test @Graded(description="MyLinkedList:sumEven()", marks=10)
	public void testMyLinkedListSumEven() throws NoSuchMethodException, SecurityException {
		MyLinkedList list = new MyLinkedList();
		assertEquals(0, list.sumEven());

		list.add(56);
		list.add(63);
		list.add(-30);
		list.add(71);
		list.add(40);
		assertEquals(66, list.sumEven());

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}

  @Test @Graded(description="MyLinkedList:swapFirstAndLast()", marks=10)
	public void testMyLinkedListSwapFirstAndLast() throws NoSuchMethodException, SecurityException {
		MyLinkedList list = new MyLinkedList();
		list.swapFirstAndLast();
		assertEquals(0, list.size());
		
		list.add(5); //[5]
		list.swapFirstAndLast();
		assertEquals(1, list.size());
		assertEquals(5, (int)list.get(0));
		
		list.add(6); //[5, 6]
		list.swapFirstAndLast(); //should become [6, 5]
		assertEquals(2, list.size());
		assertEquals(6, (int)list.get(0));
		assertEquals(5, (int)list.get(1));
		
		list.add(3); //[6, 5, 3]
		list.swapFirstAndLast(); //should become [3, 5, 6]
		assertEquals(3, list.size());
		assertEquals(3, (int)list.get(0));
		assertEquals(5, (int)list.get(1));
		assertEquals(6, (int)list.get(2));
		
		list.add(9); //[3, 5, 6, 9]
		list.swapFirstAndLast(); //should become [9, 5, 6, 3]
		assertEquals(4, list.size());
		assertEquals(9, (int)list.get(0));
		assertEquals(5, (int)list.get(1));
		assertEquals(6, (int)list.get(2));
		assertEquals(3, (int)list.get(3));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}


  @Test @Graded(marks=10, description="listWithoutMaxProductPair(List)")
	public void testListWithoutMaxProductPairList() throws NoSuchMethodException, SecurityException {
		ArrayList<Integer> list = null;
		ArrayList<Integer> asc = Question8.listWithoutMaxProductPair(list);
		assertNull(asc);

		list = new ArrayList<Integer>();
		asc = Question8.listWithoutMaxProductPair(list);
		assertNull(asc);

		list.add(-3);
		asc = Question8.listWithoutMaxProductPair(list);
		assertNull(asc);
		
		list.add(2);
		asc = Question8.listWithoutMaxProductPair(list);
		assertTrue(asc.size() == 0);
		
		list.add(1);
		asc = Question8.listWithoutMaxProductPair(list);
		assertEquals("[1]", asc.toString());
		
		list.add(-6);
		list.add(-4);
		list.add(8);
		list.add(9);
		asc = Question8.listWithoutMaxProductPair(list);
		assertEquals("[-3, 2, 1, -6, -4]", asc.toString());
		
		ArrayList<Integer> list2 = new ArrayList<>();
		//6, 1, -4, 2, 3, 4, -9
		list2.add(6);
		list2.add(1);
		list2.add(-4);
		list2.add(2);
		list2.add(3);
		list2.add(4);
		list2.add(-9);
		asc = Question8.listWithoutMaxProductPair(list2);
		assertEquals("[1, -4, 2, 3, 4]", asc.toString());
		
		ArrayList<Integer> list3 = new ArrayList<>();
		//6, -9, -6, 3, 2, -1
		list3.add(6);
		list3.add(-9);
		list3.add(-6);
		list3.add(3);
		list3.add(2);
		list3.add(-1);
		asc = Question8.listWithoutMaxProductPair(list3);
		assertEquals("[6, 3, 2, -1]", asc.toString());

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();	
	}


  @Test @Graded(description="groupMultiplyNegativeRecursive(int, int[], int)", marks=10)
	public void testGroupMultiplyNegativeRecursive() throws NoSuchMethodException, SecurityException {
		int[] a = {5,1,2,4};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, a, 10));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, a, 3));

		int[] b = {5,-1,3,2};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, b, -6));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, b, 15));

		int[] c = {5,-1,-6,2};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, c, 30));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, c, -30));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, c, -12));
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, c, 12));
		
		int[] d = {10,-1,-6,2};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, d, 6));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, d, 60));
		assertFalse(Question9.groupMultiplyNegativeRecursive(0, d, -12));
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, d, 12));

		int[] empty = {};
		assertTrue(Question9.groupMultiplyNegativeRecursive(0, empty, 1));

		currentMethodName = new Throwable().getStackTrace()[0].getMethodName();
	}



	@After
	public void logSuccess() throws NoSuchMethodException, SecurityException {
		if(currentMethodName != null) {
			Method method = getClass().getMethod(currentMethodName);
			Graded graded = method.getAnnotation(Graded.class);
			score+=graded.marks();
			result+=graded.description()+" passed. Marks awarded: "+graded.marks()+"\n";
		}
	}

	@AfterClass
	public static void wrapUp() throws IOException {
	System.out.println("Score = "+score);
		System.out.println(result);
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());
		File file = new File("report"+timeStamp+".txt");
		FileWriter writer = new FileWriter(file);
		writer.write("Score = "+score+"\n");
		writer.write(result+"\n");
		writer.flush();
		writer.close();
	}
}

package samplePracticalExam3;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//10 marks
public class Question3 { //begin class 
	/**
	 *
	 * @param list
	 * @param x
	 * @return the multiplication of all items except for items that have the same value as x
	 * return -1 if list is null or empty
	 * for example,
	 * if list = [2, 5, 80, 10, 2] and x = 80, return 2*5*10*2=200
	 * if list = [20, 30] and x = 25, return 20*30=600
	 * if list = [40] and x = 20, return 40
	 */
	public static int multiplicationBesidesX(ArrayList<Integer> list, int x) {
		return 0; //to be completed
	}
	//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="multiplicationBesidesX(ArrayList<Integer>, int)", marks=10)
	public void testMultiplicationBesidesX() throws NoSuchMethodException, SecurityException {
		assertEquals(-1, Question3.multiplicationBesidesX(null, 20)); //null list check
		ArrayList<Integer> list = new ArrayList<Integer>();
		assertEquals(-1, Question3.multiplicationBesidesX(list, -291)); //empty list check

		list.add(20);
		assertEquals(20, Question3.multiplicationBesidesX(list, 10));
		list.add(30);
		assertEquals(600, Question3.multiplicationBesidesX(list, -10));

		list.add(60);
		assertEquals(1200, Question3.multiplicationBesidesX(list, 30));

		list.add(10);
		list.add(50);
		list.add(30);
		assertEquals(10800000, Question3.multiplicationBesidesX(list, 50));

	}
} //end class (do not delete this closing bracket)

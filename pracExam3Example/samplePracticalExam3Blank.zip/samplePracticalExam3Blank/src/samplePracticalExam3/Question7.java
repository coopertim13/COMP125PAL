package samplePracticalExam3;
//IMPORTANT! Do NOT change any method headers

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;


//20 marks
class MyLinkedList {
	public Node head;

	/**
	 * DO NOT MODIFY
	 * @param item: item to be added at the end of the list
	 */
	public void add(int item) {
		Node temp = new Node(item, null);
		if(head == null) {
			head = temp;
		}
		else {
			Node cur = head;
			while(cur.next != null) {
				cur = cur.next;
			}
			cur.next = temp;
		}
	}

	/**
	 * DO NOT MODIFY
	 * @param idx: index of item to be returned
	 * @return the value of supplied index (null if index invalid)
	 */
	public Integer get(int idx) {
		Node cur = head;
		for(int i=0; i < idx && cur != null; i++) {
			cur = cur.next;
		}
		if(cur == null)
			return null;
		else
			return cur.data;
	}

	//DO NOT MODIFY
	public int size() {
		int n = 0;
		for(Node cur = head; cur != null; cur = cur.next) {
			n++;
		}
		return n;
	}

	/**
	 * 10 marks
	 *
	 * @return the sum of all even numbers in the linked list
	 * return 0 if empty or none of the items are even
	 * IMPORTANT: list should NOT BE MODIFIED.
	 * for example,
	 * head -> 20 -> 50 -> 60 -> null : return 130
	 * head -> 21 -> 50 -> 33 -> null : return 50
	 * head -> null : return 0
	 */
	public int sumEven() {
		return 0; //to be completed
	}

	/**
	 * 10 marks
	 *
	 * physically swap the first and last node
	 * for example,
	 * if head -> 20 -> 80 -> 30, it should become head -> 30 -> 80 -> 20
	 * if head -> 70 -> 10 -> 80 -> 30, it should become head -> 30 -> 10 -> 80 -> 70
	 * if head -> 50, it should stay head -> 50
	 * if head -> 50 -> 20, it should become head -> 20, 50
	 * if head -> null, it should stay head -> null
	 * 
	 * NOTE: You will have to write a special case for when there are only 2
	 * nodes in the linked list
	 */
	public void swapFirstAndLast() {
		//to be completed
	}
}

//IMPORTANT!!! DO NOT MODIFY ANY CODE BELOW THIS LINE!

public class Question7 { //begin TEST class 

	@SuppressWarnings("deprecation")
	@Rule
	public TestRule timeout = new DisableOnDebug(new Timeout(1000));

	@Test @Graded(description="MyLinkedList:sumEven()", marks=10)
	public void testMyLinkedListSumEven() throws NoSuchMethodException, SecurityException {
		MyLinkedList list = new MyLinkedList();
		assertEquals(0, list.sumEven());

		list.add(56);
		list.add(63);
		list.add(-30);
		list.add(71);
		list.add(40);
		assertEquals(66, list.sumEven());

	}

	@Test @Graded(description="MyLinkedList:swapFirstAndLast()", marks=10)
	public void testMyLinkedListSwapFirstAndLast() throws NoSuchMethodException, SecurityException {
		MyLinkedList list = new MyLinkedList();
		list.swapFirstAndLast();
		assertEquals(0, list.size());
		
		list.add(5); //[5]
		list.swapFirstAndLast();
		assertEquals(1, list.size());
		assertEquals(5, (int)list.get(0));
		
		list.add(6); //[5, 6]
		list.swapFirstAndLast(); //should become [6, 5]
		assertEquals(2, list.size());
		assertEquals(6, (int)list.get(0));
		assertEquals(5, (int)list.get(1));
		
		list.add(3); //[6, 5, 3]
		list.swapFirstAndLast(); //should become [3, 5, 6]
		assertEquals(3, list.size());
		assertEquals(3, (int)list.get(0));
		assertEquals(5, (int)list.get(1));
		assertEquals(6, (int)list.get(2));
		
		list.add(9); //[3, 5, 6, 9]
		list.swapFirstAndLast(); //should become [9, 5, 6, 3]
		assertEquals(4, list.size());
		assertEquals(9, (int)list.get(0));
		assertEquals(5, (int)list.get(1));
		assertEquals(6, (int)list.get(2));
		assertEquals(3, (int)list.get(3));

	}
} //end TEST class Question7 (do not delete this closing bracket)

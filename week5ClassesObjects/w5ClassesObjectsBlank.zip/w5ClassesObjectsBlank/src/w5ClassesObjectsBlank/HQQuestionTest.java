package w5ClassesObjectsBlank;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HQQuestionTest {

	@Test
	void HDTest() {
		Waterbottle[] arr = new Waterbottle[10];
		arr[0] = new Waterbottle(375, 5.5);
		arr[1] = new Waterbottle(375, 4.5);
		arr[2] = new Waterbottle(375, 5.50);
		arr[3] = new Waterbottle(375, 11);
		arr[4] = new Waterbottle(375, 11.0);
		arr[5] = new Waterbottle(375, 11.01);
		arr[6] = new Waterbottle(375, 14.38);
		arr[7] = new Waterbottle(375, 0);
		arr[8] = new Waterbottle(375, -4.3);
		arr[9] = new Waterbottle(375, 9.2);
		
		Waterbottle[] arr2 = new Waterbottle[7];
		arr2[0] = new Waterbottle(375, 5.5);
		arr2[1] = new Waterbottle(375, 4.5);
		arr2[2] = new Waterbottle(375, 11);
		arr2[3] = new Waterbottle(375, 11.01);
		arr2[4] = new Waterbottle(375, 14.38);
		arr2[5] = new Waterbottle(375, 0);
		arr2[6] = new Waterbottle(375, 9.2);
		
		Waterbottle[] result = HDQuestion.getSet(arr);
		assertEquals(arr2.length, result.length);
		for(int i = 0; i < result.length; i++) {
			assertEquals(arr2[i].getPrice(), result[i].getPrice());
		}
	}

}

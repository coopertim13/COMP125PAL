package linkedListPracticeQuestions;

import java.util.ArrayList;

public class MyLinkedList {
	private Node head;

	/**
	 * DO NOT MODIFY
	 * @param item: item to be added at the end of the list
	 */
	public void add(int item) {
		Node temp = new Node(item, null);
		if(head == null) {
			head = temp;
		}
		else {
			Node cur = head;
			while(cur.getNext() != null) {
				cur = cur.getNext();
			}
			cur.setNext(temp);
		}
	}

	/**
	 * DO NOT MODIFY
	 */
	public String toString() {
		if(head == null)
			return "[]";
		String result = "[";
		Node current = head;
		while(current != null) {
			result = result + current.getData() + ", ";
			current = current.getNext();
		}
		return result.substring(0, result.length()-2) + "]";
	}

	/**
	 * DO NOT MODIFY
	 * @param idx: index of item to be returned
	 * @return the value of supplied index (null if index invalid)
	 */
	public Integer get(int idx) {
		Node cur = head;
		for(int i=0; i < idx && cur != null; i++) {
			cur = cur.getNext();
		}
		if(cur == null)
			return null;
		else
			return cur.getData();
	}

	/**
	 * QUESTION 1 (P/Cr level). Worth 20 marks 
	 * (Worth more as it's a basic skill for incoming COMP225 students) 
	 * @param min: lower bound
	 * @param max: upper bound
	 * @return number of items that are in the range [min, max] (inclusive on both sides)
	 * For example, 
	 * if state of list is:
	 * head -> 2 -> 8 -> -5 -> 0 -> 12 -> 1 -> null, min = 0, max = 8, return 4
	 * 
	 * if state of list is:
	 * head -> 2 -> 8 -> -5 -> 0 -> 12 -> 1 -> null, min = 100, max = 200, return 0
	 * 
	 * if state of list is:
	 * head -> 2 -> 8 -> -5 -> 0 -> 12 -> 1 -> null, min = 10, max = 0, return 0 
	 * (no item can be in range [10, 0]
	 * 
	 * if state of list is:
	 * head -> 2 -> 8 -> -5 -> 0 -> 12 -> 1 -> null, min = -10, max = -2, return 1
	 */
	public int countInRange(int min, int max) {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 2 (P/Cr level). Worth 20 marks 
	 * (Worth more as it's a basic skill for incoming COMP225 students) 
	 * @param n
	 * @return sum of items that are more than the given item
	 * For example, 
	 * head -> null, n = 0: return 0
	 * head -> 10 -> null, n = 0: return 10
	 * head -> 10 -> null, n = 10: return 0 (10 is not more than 10)
	 * head -> 2 -> 8 -> 5 -> 0 -> 12 -> 1 -> null, n = 5, return 20 
	 * head -> 5 -> 4 -> 3 -> 2 -> 10 -> null, n = 4, return 15 
	 */
	public int sumItemsMoreThan(int n) {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 3. Worth 10 marks
	 * @return the number of items in the list that have duplicates
	 * For example,
	 * head -> 5 -> 5 -> 2 -> 1 -> 8 -> null: return 2
	 * head -> 5 -> 2 -> 1 -> 8 -> 9 -> null: return 0
	 * head -> 8 -> 4 -> 7 -> 1 -> 8 -> null: return 2
	 * head -> 7 -> 4 -> 7 -> 4 -> 3 -> null: return 4
	 * head -> 3 -> 2 -> 3 -> 3 -> 2 -> null: return 5
	 */
	public int countDuplicates() {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 4. Worth 10 marks
	 * @return the number of items in the list that are unique
	 */
	public int countUnique() {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 5. Worth 10 marks
	 * @param item: item that should be removed from the list
	 * remove all occurrences of the given item from the list
	 */
	public void removeAll(int item) {
		//to be completed
	}
	
	/**
	 * QUESTION 6. Worth 10 marks
	 * @param item: value that should be compared to each nodes data in list
	 * @return the data contained within the node that is 2 places after the
	 * first occurrence of the node whose data is equal to the parameter "item".
	 * If the node containing "item" is the last or second last
	 * node in the list, return the data of the last node.
	 * If there are no nodes containing "item", return
	 * the data of the last node.
	 * If list is null, return 0.
	 * For example,
	 * head -> 2 -> 8 -> 8 -> 0 -> 12 -> 1 -> null, item = 8, return 0
	 * head -> 2 -> 7 -> 2 -> 3 -> 4 -> 2 -> null, item = 2, return 2
	 * head -> 5 -> 2 -> 3 -> 7 -> 0 -> 9 -> null, item = 7, return 9
	 * head -> 5 -> 2 -> 3 -> 7 -> 0 -> 9 -> null, item = 0, return 9
	 * head -> 5 -> 2 -> 3 -> 7 -> 0 -> 9 -> null, item = 9, return 9
	 * head -> 5 -> 2 -> 3 -> 7 -> 0 -> 1 -> null, item = 12, return 1
	 */
	public int nodeTwoAfter(int item) {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 7. Worth 10 marks
	 * @param item: data value for node to be added
	 * @param index: index of node to be added
	 * Add a new node with data "item" one place
	 * after "index" in the linked list.
	 * 
	 * If index is more than the index of the last node,
	 * insert the new node as the last node in the list.
	 * 
	 * If index is less than or equal to -1, insert the new node
	 * as the first node in the list.
	 * 
	 * If list is null, item is to be inserted as first item, no matter the index passed.
	 * 
	 * For example,
	 * head -> 2 -> 8 -> 8 -> 0 -> 12 -> 1 -> null, item = 7, index = 0
	 * 		becomes: head -> 2 -> 7 -> 8 -> 8 -> 0 -> 12 -> 1 -> null
	 * 
	 * head -> 2 -> 7 -> 2 -> 3 -> 4 -> 2 -> null, item = 2, index = 5
	 * 		becomes: head -> 2 -> 7 -> 2 -> 3 -> 4 -> 2 -> 2 -> null
	 * 
	 * head -> 5 -> 2 -> 3 -> 7 -> 0 -> 9 -> null, item = 7, index = -2
	 * 		becomes: head -> 7 -> 5 -> 2 -> 3 -> 7 -> 0 -> 9 -> null
	 * 
	 * head -> 5 -> 2 -> 3 -> 7 -> 0 -> 9 -> null, item = 12, index = 99
	 * 		becomes: head -> 5 -> 2 -> 3 -> 7 -> 0 -> 9 -> 12 -> null
	 * 
	 * head -> null, item = 9, index = -82
	 * 		becomes: head -> 9 -> null
	 */
	public void addCustom(int item, int index) {
		//to be completed
	}
	
	/**
	 * QUESTION 8. Worth 10 marks.
	 * @param values: indexes of items to be added to new ArrayList
	 * @return: an ArrayList of the data for the nodes whose indexes
	 * are contained within "values".
	 * 
	 * The ArrayList being returned also cannot contain
	 * any duplicates. If 2 or more items of the same value
	 * are added to the list, keep only the first occurrence
	 * and remove the rest.
	 * 
	 * Assume the indexes array is in ascending order
	 * 
	 * You may use helper methods.
	 * 
	 * For example,
	 * head -> 2 -> 4 -> 5 -> 7 -> 9 -> 0 -> 4 -> 3 -> null, indexes = [0, 4, 5]
	 * 		return {2, 9, 0}
	 * 
	 * head -> 2 -> 4 -> 2 -> 4 -> 4 -> 5 -> 6 -> 5 -> null, indexes = [0, 2, 3, 4, 5, 6, 7]
	 * 		return {2, 4, 5, 6}
	 */
	public ArrayList<Integer> customArrayListFromLinkedList(int[] indexes) {
		ArrayList<Integer> toReturn = new ArrayList<Integer>();
		return toReturn; //to be completed
	}
}

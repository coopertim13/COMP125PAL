package linkedListPracticeQuestions;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;

public class MyLinkedListTest {
	private static String result = "";
	private static int score = 0;
	
	@Test @Graded(description="MyLinkedList:countInRange(int,int)",marks=20)
	public void testCountInRangeMyLinkedList() {
		MyLinkedList list = new MyLinkedList();
		list.add(5);
		list.add(10);
		list.add(2);
		list.add(8);
		list.add(-4);
		list.add(0);
		assertEquals(0, list.countInRange(100,  200));
		assertEquals(5, list.countInRange(0, 10));
		assertEquals(6, list.countInRange(-4, 10));
		assertEquals(1, list.countInRange(7, 9));
		assertEquals(1, list.countInRange(2, 2));
		score+=20; 
		result="MyLinkedList:countInRange(int,int) passed (20 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
	}
	
	@Test @Graded(description="MyLinkedList:sumItemsMoreThan(int)",marks=20)
	public void testSumItemsMoreThan() {
		MyLinkedList list = new MyLinkedList();
		list.add(5);
		list.add(10);
		list.add(2);
		list.add(8);
		list.add(-4);
		list.add(0);
		assertEquals(0, list.sumItemsMoreThan(100));
		assertEquals(25, list.sumItemsMoreThan(0));
		assertEquals(21, list.sumItemsMoreThan(-6));
		assertEquals(18, list.sumItemsMoreThan(7));
		assertEquals(23, list.sumItemsMoreThan(2));
		score+=20; 
		result="MyLinkedList:sumItemsMoreThan(int) passed (20 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
	}
	
	@Test @Graded(description="MyLinkedList:countDuplicates()",marks=10)
	public void testCountDuplicatesMyLinkedList() {
		MyLinkedList list = new MyLinkedList();
		list.add(0);
		list.add(2);
		list.add(3);
		list.add(5);
		list.add(6);
		assertEquals(0, list.countDuplicates());
		list.add(0);
		assertEquals(2, list.countDuplicates());
		MyLinkedList list2 = new MyLinkedList();
		list2.add(2);
		list2.add(2);
		list2.add(2);
		list2.add(4);
		assertEquals(3, list2.countDuplicates());
		MyLinkedList list3 = new MyLinkedList();
		list3.add(2);
		list3.add(1);
		list3.add(2);
		list3.add(3);
		list3.add(3);
		list3.add(2);
		assertEquals(5, list3.countDuplicates());
		
		score+=10; 
		result="MyLinkedList:countDuplicates() passed (10 marks)";
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
	}
	
	@Test @Graded(description="MyLinkedList:countUnique()",marks=10)
	public void testCountUniqueMyLinkedList() {
		MyLinkedList list = new MyLinkedList();
		list.add(0);
		list.add(2);
		list.add(3);
		list.add(5);
		list.add(6);
		assertEquals(5, list.countUnique());
		list.add(0);
		assertEquals(4, list.countUnique());
		MyLinkedList list2 = new MyLinkedList();
		list2.add(2);
		list2.add(2);
		list2.add(2);
		list2.add(4);
		assertEquals(1, list2.countUnique());
		MyLinkedList list3 = new MyLinkedList();
		list3.add(2);
		list3.add(1);
		list3.add(2);
		list3.add(3);
		list3.add(3);
		list3.add(2);
		assertEquals(1, list3.countUnique());
		
		score+=10; 
		result="MyLinkedList:countUnique() passed (10 marks)";
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
	}

	@Test @Graded(description="MyLinkedList:removeAll(int)",marks=10)
	public void testRemoveAllMyLinkedList() {
		MyLinkedList list = new MyLinkedList();
		list.add(8);
		list.add(8);
		list.add(8);
		list.add(8);
		list.add(5);
		list.add(10);
		list.add(2);
		list.add(8);
		list.add(-4);
		list.add(8);
		list.add(8);
		list.add(0);
		list.add(8);
		list.add(8);
		list.add(8);
		list.add(8);
		list.removeAll(8);
		assertEquals("[5, 10, 2, -4, 0]", list.toString());
		
		list = new MyLinkedList();
		list.add(20);
		list.add(20);
		list.add(20);
		list.add(20);
		list.add(20);
		list.add(20);
		list.add(20);
		list.add(20);
		list.add(20);
		list.removeAll(20);
		assertEquals("[]", list.toString());
		
		list = new MyLinkedList();
		list.add(20);
		list.add(20);
		list.add(20);
		list.add(20);
		list.removeAll(50);
		assertEquals("[20, 20, 20, 20]", list.toString());
		
		score+=10; 
		result="MyLinkedList:removeAll(int) passed (10 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
	}
	
	@Test @Graded(description="MyLinkedList:nodeTwoAfter(int)",marks=10)
	public void testNodeTwoAfterMyLinkedList() {
		MyLinkedList list = new MyLinkedList();
		list.add(0);
		list.add(2);
		list.add(3);
		list.add(5);
		list.add(6);
		assertEquals(6, list.nodeTwoAfter(3));
		assertEquals(6, list.nodeTwoAfter(6));
		assertEquals(6, list.nodeTwoAfter(5));
		assertEquals(3, list.nodeTwoAfter(0));
		assertEquals(6, list.nodeTwoAfter(1));
		
		score+=10; 
		result="MyLinkedList:nodeTwoAfter(int) passed (10 marks)";
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
		
	}
	
	@Test @Graded(description="MyLinkedList:addCustom(int, int)",marks=10)
	public void testAddCustomMyLinkedList() {
		MyLinkedList list = new MyLinkedList();
		list.add(0);
		list.add(2);
		list.add(3);
		list.add(5);
		list.add(6);
		list.addCustom(-1, -2);
		assertEquals("[-1, 0, 2, 3, 5, 6]", list.toString());
		list.addCustom(1, 1);
		assertEquals("[-1, 0, 1, 2, 3, 5, 6]", list.toString());
		list.addCustom(4, 4); 
		assertEquals("[-1, 0, 1, 2, 3, 4, 5, 6]", list.toString());
		list.addCustom(7, 7);
		assertEquals("[-1, 0, 1, 2, 3, 4, 5, 6, 7]", list.toString());
		list.addCustom(24, 99);
		assertEquals("[-1, 0, 1, 2, 3, 4, 5, 6, 7, 24]", list.toString());
		MyLinkedList list2 = new MyLinkedList();
		list2.addCustom(2, 9);
		assertEquals("[2]", list2.toString());
		list2.addCustom(4, 1);
		
		score+=10; 
		result="MyLinkedList:addCustom(int,int) passed (10 marks)";
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
	}
	
	@Test @Graded(description="MyLinkedList:customArrayListFromLinkedList(int[])",marks=10)
	public void testCustomArrayListFromLinkedListMyLinkedList() {
		MyLinkedList list = new MyLinkedList();
		list.add(2);
		list.add(4);
		list.add(5);
		list.add(7);
		list.add(9);
		list.add(0);
		list.add(4);
		list.add(3);
		int[] array = new int[3];
		array[0] = 0;
		array[1] = 4;
		array[2] = 5;
		ArrayList<Integer> toCompare = new ArrayList<Integer>();
		toCompare.add(2);
		toCompare.add(9);
		toCompare.add(0);
		assertEquals(toCompare, list.customArrayListFromLinkedList(array));
		MyLinkedList list2 = new MyLinkedList();
		list2.add(2);
		list2.add(4);
		list2.add(2);
		list2.add(4);
		list2.add(4);
		list2.add(5);
		list2.add(6);
		list2.add(5);
		int[] array2 = new int[7];
		array2[0] = 0;
		array2[1] = 2;
		array2[2] = 3;
		array2[3] = 4;
		array2[4] = 5;
		array2[5] = 6;
		array2[6] = 7;
		toCompare.clear();
		toCompare.add(2);
		toCompare.add(4);
		toCompare.add(5);
		toCompare.add(6);
		assertEquals(toCompare, list2.customArrayListFromLinkedList(array2));
		toCompare.clear();
		MyLinkedList list3 = new MyLinkedList();
		assertEquals(toCompare, list3.customArrayListFromLinkedList(array2));
		
		score+=10; 
		result="MyLinkedList:customArrayListFromLinkedList(int[]) passed (10 marks)";
		
		System.out.println(result);
		System.out.println("Total: "+score+"/100");
	}

}

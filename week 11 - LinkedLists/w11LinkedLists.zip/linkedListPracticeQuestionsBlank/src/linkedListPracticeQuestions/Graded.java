package linkedListPracticeQuestions;


public @interface Graded {

	int marks();

	String description();

}

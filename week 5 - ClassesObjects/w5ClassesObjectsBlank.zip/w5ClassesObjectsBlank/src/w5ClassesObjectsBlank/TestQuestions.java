package w5ClassesObjectsBlank;
import static org.junit.Assert.*;
import org.junit.*;
import org.junit.jupiter.api.BeforeEach;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterAll;

public class TestQuestions {
	private static int score = 0;
	private static String result = "";
	private Waterbottle[] arr = new Waterbottle[10];
	
	@BeforeEach
	void run() {
		arr[0] = new Waterbottle(375, 5.5);
		arr[1] = new Waterbottle(375, 4.5);
		arr[2] = new Waterbottle(375, 5.50);
		arr[3] = new Waterbottle(375, 11);
		arr[4] = new Waterbottle(375, 11.0);
		arr[5] = new Waterbottle(375, 11.01);
		arr[6] = new Waterbottle(375, 14.38);
		arr[7] = new Waterbottle(375, 0);
		arr[8] = new Waterbottle(375, -4.3);
		arr[9] = new Waterbottle(375, 9.2);
	}
	
	@Test @Graded(description="Waterbottle:setCapacity(int)", marks=5)
	public void testSetCapacityWaterbottle() {
		Waterbottle b = new Waterbottle();
		b.setCapacity(200);
		assertEquals(200, b.getCapacity());
		b.setCapacity(-12);
		assertEquals(0, b.getCapacity());
		b.setCapacity(0);
		assertEquals(0, b.getCapacity());
		score+=5;
		result+="Waterbottle:setCapacity(int) passed (5 marks)\n";
	}
	
	@Test @Graded(description="Waterbottle:setPrice(double)", marks=5)
	public void testSetPriceWaterbottle() {
		Waterbottle b = new Waterbottle();
		b.setPrice(1.5);
		assertEquals(0.75, b.getPrice(), 0.01);
		b.setPrice(-12.3);
		assertEquals(0, b.getPrice(), 0.01);
		b.setPrice(0);
		assertEquals(0, b.getPrice(), 0.01);
		score+=5;
		result+="Waterbottle:setPrice(double) passed (5 marks)\n";
	}

	@Test @Graded(description="Waterbottle()", marks=5)
	public void testWaterbottle() {
		Waterbottle b = new Waterbottle();
		assertEquals(375, b.getCapacity());
		assertEquals(2.75, b.getPrice(), 0.01);
		score+=5;
		result+="Waterbottle() passed (5 marks)\n";
	}
	
	@Test @Graded(description="Waterbottle(int, double)", marks=5)
	public void testWaterbottleIntDouble() {
		Waterbottle b = new Waterbottle(300, 2.5);
		assertEquals(1.25, b.getPrice(), 0.01);
		assertEquals(300, b.getCapacity());
		score+=5;
		result+="Waterbottle(int, double) passed (5 marks)\n";
	}

	//utility methods
	@Test @Graded(description="Waterbottle:totalCostPerMl()", marks=10)
	public void testTotalCostPerMl() {
		Waterbottle b = new Waterbottle(300, 4.5);
		assertEquals(0.015, b.totalCostPerMl(), 0.01);
		b = new Waterbottle(800, 4.75);
		assertEquals(0.0059375, b.totalCostPerMl(), 0.01);
		score+=10;
		result+="Waterbottle:totalCostPerMl() passed (10 marks)\n";
	}
	
	@Test @Graded(description="Waterbottle:compareTo(Waterbottle)", marks=10)
	public void testCompareToWaterbottle() {
		Waterbottle a = new Waterbottle(400, 3.95);
		Waterbottle b = new Waterbottle(348, 7.59);
		Waterbottle c = new Waterbottle(150, 2.25);
		Waterbottle d = new Waterbottle(390, 2.25);
		
		assertEquals(1, b.compareTo(a));
		assertEquals(-1, c.compareTo(a));
		assertEquals(0, c.compareTo(d));
		
		score+=10;
		result+="Waterbottle:compareTo(Waterbottle) passed (10 marks)\n";
	}
	
	@Test @Graded(description="Questions:customWaterbottle()", marks=10)
	public void testCustomWaterbottle() {
		Waterbottle a = Questions.customWaterbottle();
		
		assertEquals(450, a.getCapacity());
		assertEquals(0, a.getPrice(), 0.01);
		
		score+=10;
		result+="Questions:customWaterBottle() passed (10 marks)\n";
	}
	
	@Test @Graded(description="Questions:numMoreThanEqualToFiveFifty(Waterbottle[])", marks=10)
	public void testNumMoreThanEqualToFiveFifty() {
		int count = Questions.numMoreThanEqualToFiveFifty(arr);
		assertEquals(4, count);
		
		score+=10;
		result+="Questions:numMoreThanEqualToFiveFifty(Waterbottle[]) passed (10 marks)\n";
	}
	
	@Test @Graded(description="Questions:averagePrice(Waterbottle[])", marks=20)
	public void testAveragePrice() {
		double average = 3.6045;
		assertEquals(average, Questions.averagePrice(arr), 0.01);
		
		score+=20;
		result+="Questions:averagePrice(Waterbottle[]) passed (20 marks)\n";
	}
	
	@Test @Graded(description="Questions:priceComparison(Waterbottle, Waterbottle[])", marks=20)
	public void testPriceComparison() {
		Waterbottle comparison = new Waterbottle(550, 9.2);
		int count = Questions.priceComparison(comparison, arr);
		assertEquals(6, count);
		
		score+=20;
		result+="Questions:priceComparison(Waterbottle, Waterbottle[]) passed (20 marks)\n";
	}
	
	@AfterAll
	public static void wrapUp() throws IOException {
	System.out.println("Score = "+score+"/100");
		System.out.println(result);
	}
}
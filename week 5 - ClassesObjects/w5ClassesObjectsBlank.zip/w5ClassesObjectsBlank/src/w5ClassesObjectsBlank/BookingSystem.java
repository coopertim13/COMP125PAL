package w5ClassesObjectsBlank;

//I HIGHLY ADVISE YOU COMPLETE compareTo METHOD IN DATE BEFORE COMPLETING BOOKING SYSTEM

public class BookingSystem {
	public static final double costPerNightPerPerson = 34.50;
	public Date checkIn;
	public Date checkOut;
	public int numOfVisitors;
	
	public BookingSystem() {
		this.checkIn = new Date(29, 8, 2019);
		this.checkOut = new Date(30, 8, 2019);
		this.numOfVisitors = 0;
	}
	
	/**
	 * @param in: value intended for checkIn
	 * checkIn should be the later between 29/8/2019 and in
	 * @param out: value intended for CheckOut
	 * checkOut should be the later between 30/8/2019 and out
	 * @param visitors
	 * assign the higher of 1 and visitors into numOfVisitors
	 */
	public BookingSystem(Date in, Date out, int visitors) {
		this.checkIn = new Date(0,0,0);
		this.checkOut = new Date(0,0,0);
		//to be completed (these values are only here to stop NullPointerException)
	}
	
	
	/**
	 * @return the number of days (including check in and check out) of visit
	 * You may assume the booking is within the same year
	 * You may also assume the checkOut date is after the checkIn date
	 * You may also assume every month has 30 days
	 */
	public int durationInDays() {
		return 0; //to be completed
	}
	
	
	/**
	 * 
	 * @return the total cost of the stay
	 */
	public double totalCost() {
		return 0; //to be completed
	}
	
	
	/**
	 * 
	 * @param n
	 * Assume children get a 50% discount on costPerNight
	 * @return total cost of stay if the numOfVisitors includes n amount of children
	 * if n >= numOfVisitors, assume all of the visitors are children but 1
	 * Assume n>=0
	 */
	public double totalCostWithChildren(int n) {
		return 0; //to be completed
	}
	
	
	/**
	 * HD QUESTION
	 * @param bookings
	 * @return true if any bookings within bookings array overlap, false otherwise
	 * You may assume all bookings are within the same month
	 */
	public static boolean doubleBooked(BookingSystem[] bookings) {
		return true; //to be completed
	}
}

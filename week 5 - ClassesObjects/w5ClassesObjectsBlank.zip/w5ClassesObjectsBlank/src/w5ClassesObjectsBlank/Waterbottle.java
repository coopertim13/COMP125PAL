package w5ClassesObjectsBlank;

public class Waterbottle {
	private int capacity;
	private double price;
	
	/**
	 * complete getCapacity() so it returns capacity of Waterbottle object
	 */
	public int getCapacity() {
		return 0; //to be completed
	}
	
	/**
	 * complete getPrice() so it returns price of Waterbottle object
	 */
	public double getPrice() {
		return 0; //to be completed
	}
	
	/**
	 * set instance variable capacity to the higher between 0 and the parameter
	 * @param c
	 */
	public void setCapacity(int c) {
		//to be completed
	}
	
	/**
	 * set instance variable price to half the value of the parameter p
	 * Ensure that the price passed is >= 0
	 * If the price is < 0, set instance variable price to 0
	 * @param p
	 */
	public void setPrice(double p) {
		//to be completed
	}
	
	/**
	 * default constructor - set instance variable capacity to 375,
	 * and price to 5.5 (which will later be changed to 2.75 by setPrice)
	 */
	public Waterbottle() {
		//to be completed
	}
	
	/**
	 * parameterized constructor: 
	 * set capacity to c and price to p
	 * @param c
	 * @param p
	 */
	public Waterbottle(int c, double p) {
		//to be completed
	}
	
	/**
	 * 
	 * Assume capacity is measured in milliliters (ml)
	 * @return total cost per ml for this waterbottle, calculated 
	 * as the price divided by the capacity
	 */
	public double totalCostPerMl() {
		return 0; //to be completed
	}
	
	/**
	 * 
	 * @param other
	 * @return 1 if calling price of calling object is more than price of parameter object
	 * -1 if calling price of calling object is less than price of parameter object
	 *  0 if calling price of calling object is same as price of parameter object
	 */
	public int compareTo(Waterbottle other) {
		return 0; //to be completed
	}
}

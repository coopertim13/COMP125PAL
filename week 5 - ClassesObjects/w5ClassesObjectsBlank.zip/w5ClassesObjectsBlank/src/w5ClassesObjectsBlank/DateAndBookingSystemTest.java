package w5ClassesObjectsBlank;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DateAndBookingSystemTest {

	@Test
	void testDateCompareTo() {
		Date d1 = new Date(23,12,1999);
		Date d2 = new Date(23,12,1999);
		Date d3 = new Date(22,12,1999);
		Date d4 = new Date(24,12,1999);
		Date d5 = new Date(23,11,1999);
		Date d6 = new Date(23,1,2000);
		Date d7 = new Date(23,2,2000);
		assertEquals(0, d1.compareTo(d2));
		assertEquals(-1, d3.compareTo(d2));
		assertEquals(1, d4.compareTo(d1));
		assertEquals(-1, d5.compareTo(d1));
		assertEquals(1, d6.compareTo(d5));
		assertEquals(-1, d6.compareTo(d7));
	}
	
	@Test
	void testCustomBookingSystemConstructor() {
		Date d1 = new Date(29, 8, 2019);
		Date d2 = new Date(30, 8, 2019);
		BookingSystem t1 = new BookingSystem(new Date(30, 7, 2019), new Date(30, 8, 2019), 4);
		assertEquals(d1.getDay(), t1.checkIn.getDay());
		assertEquals(d1.getMonth(), t1.checkIn.getMonth());
		assertEquals(d1.getYear(), t1.checkIn.getYear());
		assertEquals(d2.getDay(), t1.checkOut.getDay());
		assertEquals(d2.getMonth(), t1.checkOut.getMonth());
		assertEquals(d2.getYear(), t1.checkOut.getYear());
		assertEquals(4, t1.numOfVisitors);
		
		t1 = new BookingSystem(new Date(28, 5, 2020), new Date(24, 5, 2019), -5);
		assertEquals(28, t1.checkIn.getDay());
		assertEquals(5, t1.checkIn.getMonth());
		assertEquals(2020, t1.checkIn.getYear());
		assertEquals(d2.getDay(), t1.checkOut.getDay());
		assertEquals(d2.getMonth(), t1.checkOut.getMonth());
		assertEquals(d2.getYear(), t1.checkOut.getYear());
		assertEquals(1, t1.numOfVisitors);
	}
	
	@Test
	void testDurationInDays() {
		Date d1 = new Date(29, 8, 2019);
		Date d2 = new Date(30, 8, 2019);
		BookingSystem b1 = new BookingSystem(d1,d2,1);
		assertEquals(2, b1.durationInDays());
		
		d1 = new Date(30, 8, 2019);
		d2 = new Date(30, 8, 2019);
		b1 = new BookingSystem(d1,d2,1);
		assertEquals(1, b1.durationInDays());
		
		d1 = new Date(12, 8, 2020);
		d2 = new Date(30, 9, 2020);
		b1 = new BookingSystem(d1,d2,1);
		assertEquals(49, b1.durationInDays());
		
		d1 = new Date(9, 5, 2020);
		d2 = new Date(29, 9, 2020);
		b1 = new BookingSystem(d1,d2,1);
		assertEquals(141, b1.durationInDays());
		
		d1 = new Date(9, 5, 2020);
		d2 = new Date(9, 7, 2020);
		b1 = new BookingSystem(d1,d2,1);
		assertEquals(61, b1.durationInDays());
	}
	
	@Test
	void testTotalCost() {
		Date d1 = new Date(29, 8, 2019);
		Date d2 = new Date(30, 8, 2019);
		BookingSystem b1 = new BookingSystem(d1,d2,1);
		assertEquals(69, b1.totalCost(), 0.01);
		
		d1 = new Date(30, 8, 2019);
		d2 = new Date(30, 8, 2019);
		b1 = new BookingSystem(d1,d2,1);
		assertEquals(34.50, b1.totalCost(), 0.01);
		
		d1 = new Date(12, 8, 2020);
		d2 = new Date(30, 9, 2020);
		b1 = new BookingSystem(d1,d2,3);
		assertEquals(5071.5, b1.totalCost(), 0.01);
		
		d1 = new Date(9, 5, 2020);
		d2 = new Date(29, 9, 2020);
		b1 = new BookingSystem(d1,d2,7);
		assertEquals(34051.5, b1.totalCost(), 0.01);
	}
	
	@Test
	void testTotalCostWithChildren() {
		Date d1 = new Date(29, 8, 2019);
		Date d2 = new Date(30, 8, 2019);
		BookingSystem b1 = new BookingSystem(d1,d2,1);
		assertEquals(69, b1.totalCostWithChildren(0), 0.01);
		
		d1 = new Date(30, 8, 2019);
		d2 = new Date(30, 8, 2019);
		b1 = new BookingSystem(d1,d2,1);
		assertEquals(34.50, b1.totalCostWithChildren(1), 0.01);
		
		d1 = new Date(12, 8, 2020);
		d2 = new Date(30, 9, 2020);
		b1 = new BookingSystem(d1,d2,3);
		assertEquals(4226.25, b1.totalCostWithChildren(1), 0.01);
		
		d1 = new Date(9, 5, 2020);
		d2 = new Date(29, 9, 2020);
		b1 = new BookingSystem(d1,d2,2);
		assertEquals(7296.75, b1.totalCostWithChildren(2), 0.01);
		
		b1 = new BookingSystem(d1,d2,3);
		assertEquals(9729, b1.totalCostWithChildren(2), 0.01);
	}
	
	@Test
	void testDoubleBooked() {
		BookingSystem[] bookings = new BookingSystem[3];
		bookings[0] = new BookingSystem(new Date(29,8,2020), new Date(30,8,2020), 4);
		bookings[1] = new BookingSystem(new Date(29,8,2020), new Date(30,8,2020), 3);
		bookings[2] = new BookingSystem(new Date(27,8,2020), new Date(28,8,2020), 7);
		assertTrue(BookingSystem.doubleBooked(bookings));
		
		bookings[0] = new BookingSystem(new Date(12,11,2019), new Date(13,11,2019), 4);
		bookings[1] = new BookingSystem(new Date(14,11,2019), new Date(27,11,2019), 3);
		bookings[2] = new BookingSystem(new Date(4,11,2019), new Date(9,11,2019), 7);
		assertFalse(BookingSystem.doubleBooked(bookings));
		
		bookings[0] = new BookingSystem(new Date(26,8,2021), new Date(28,8,2021), 4);
		bookings[1] = new BookingSystem(new Date(3,8,2021), new Date(5,8,2021), 3);
		bookings[2] = new BookingSystem(new Date(23,8,2021), new Date(30,8,2021), 7);
		assertTrue(BookingSystem.doubleBooked(bookings));
		
		bookings[0] = new BookingSystem(new Date(26,8,2021), new Date(28,8,2021), 4);
		bookings[1] = new BookingSystem(new Date(3,8,2021), new Date(5,8,2021), 3);
		bookings[2] = new BookingSystem(new Date(4,8,2021), new Date(7,8,2021), 7);
		assertTrue(BookingSystem.doubleBooked(bookings));
		
		bookings[0] = new BookingSystem(new Date(26,8,2021), new Date(28,8,2021), 4);
		bookings[1] = new BookingSystem(new Date(3,8,2021), new Date(5,8,2021), 3);
		bookings[2] = new BookingSystem(new Date(5,8,2021), new Date(22,8,2021), 7);
		assertTrue(BookingSystem.doubleBooked(bookings));
	}

}

package w5ClassesObjectsBlank;

public class Questions {
	/**
	 * QUESTION 1
	 * Create a Waterbottle object with capacity 450ml and price -4.35
	 * @return this object
	 * NOTE: The Waterbottle object returned should have a capacity of 450ml and
	 * a price of 0 (see setPrice(double p) if confused)
	 */
	public static Waterbottle customWaterbottle() {
		return new Waterbottle(); //to be completed
	}
	
	/**
	 * QUESTION 2
	 * @param data
	 * @return the number of Waterbottle objects that have a price of
	 * more than or equal to $5.50
	 */
	public static int numMoreThanEqualToFiveFifty(Waterbottle[] data) {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 3
	 * @param data
	 * @return the average price of all of the Waterbottle objects
	 * contained within data
	 */
	public static double averagePrice(Waterbottle[] data) {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 4
	 * @param single
	 * @param array
	 * @return the number of Waterbottle objects in 'array'
	 * that have a price less than or equal to 'single'
	 */
	public static int priceComparison(Waterbottle single, Waterbottle[] array) {
		return 0; //to be completed
	}
}

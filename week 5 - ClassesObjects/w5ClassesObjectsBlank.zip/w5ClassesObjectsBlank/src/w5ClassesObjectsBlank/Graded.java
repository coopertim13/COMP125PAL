package w5ClassesObjectsBlank;
public @interface Graded {
	String description();
	int marks();
}

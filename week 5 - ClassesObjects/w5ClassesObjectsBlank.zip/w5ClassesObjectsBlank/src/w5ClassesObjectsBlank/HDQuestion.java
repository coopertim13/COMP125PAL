package w5ClassesObjectsBlank;

public class HDQuestion {
	/**
	 * in math, a "set" is defined as a collection of **distinct** items.
	 * Thus, {1,7,2,9} is a set, but {1,7,2,1,9} is not (since 1 occurs multiple times).
	 * @param data
	 * @return a "set" obtained from the passed Waterbottle array, based on each
	 * Waterbottle objects PRICE
	 * The order of the items should be the order in of the 
	 * first occurrences of the items in the passed array.
	 * 
	 * For example, if the Waterbottle array had these PRICES for each object:
	 * {4.5, 4.2, 9.5, 4.5, 7.65, 4.2, 3.4, 4.2}
	 * the Waterbottle array PRICES for all objects in array would be:
	 * {4.5, 4.2, 9.5, 7.65, 3.4}
	 */
	
  public static Waterbottle[] getSet(Waterbottle[] data) {
	  return new Waterbottle[0]; //to be completed
  }
}

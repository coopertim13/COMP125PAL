package customArrayListBlank;

public @interface Graded {

	int marks();

	String description();

}

package customArrayListBlank;

import java.util.ArrayList;
import java.util.Arrays;

public class MyArrayList {
	private int[] a;
	private final static int MAX_SIZE = 500;
	private final static int INC_SIZE = 5;
	private final static int DEFAULT_SIZE = 5;
	private int count;

	/**
	 * DO NOT MODIFY
	 * create a list with an initial size of DEFAULT_SIZE
	 */
	public MyArrayList() {
		a = new int[DEFAULT_SIZE];
		count = 0; //currently 0 items added to list
	}

	/**
	 * DO NOT MODIFY
	 * create a list with an initial size of n
	 * @param n
	 */
	public MyArrayList(int n) {
		if(n > 0 && n <= MAX_SIZE)
			a = new int[n];
		else
			a = new int[DEFAULT_SIZE];
		count = 0; //currently 0 items added to list
	}

	// DO NOT MODIFY
	public String toString() {
		if(count == 0)
			return "[]";
		String result = "[";
		for(int i=0; i<count; i++) {
			if(i < count - 1)
				result+=a[i]+", ";
			else
				result+=a[i]+"]";
		}
		return result;
	}

	/**
	 * DO NOT MODIFY
	 * grow the resident array by INC_SIZE
	 */
	public void grow() {
		int[] temp = new int[a.length + INC_SIZE];

		//copy all items to new array
		for(int i=0; i<a.length; i++)
			temp[i] = a[i];

		//update the reference (java's garbage collection handles the old array)
		a = temp;
	}
	// DO NOT MODIFY
	public boolean isFull() {
		return count == a.length;
	}

	// DO NOT MODIFY
	public int indexOf(int item) {
		for(int i=0; i<count; i++)
			if(a[i] == item)
				return i;
		return -1;
	}

	/**
	 * DO NOT MODIFY
	 * @return number of items in the list
	 */
	public int size() {
		return count;
	}
	
	/**
	 * DO NOT MODIFY
	 * Adds item to a
	 */
	public void add(int item) {
		if(isFull()) {
			grow();
		}
		a[count] = item;
		count++;
	}

	/**
	 * DO NOT MODIFY
	 * @return capacity of the list
	 */
	public int capacity() {
		return a.length;
	}

	/**
	 * DO NOT MODIFY
	 * @param idx: index from which the item should be returned
	 * @return null if index is invalid, otherwise the item at that index
	 */
	public Integer get(int idx) {
		if(idx < 0 || idx >= count) 
			return null;
		return a[idx];
	}
	
	/**
	 * QUESTION 1. Worth 10 marks
	 * @param index
	 * Remove the item at index from a
	 * 
	 * If the index is invalid, make no changes to a
	 * 
	 */
	public void removeAtIndex(int index) {
		//to be completed
	}
	
	/**
	 * QUESTION 2. Worth 10 marks
	 * @param items
	 * Remove all from a contained within items
	 * 
	 * For example,
	 * items = {4, 5, 2}, a = {5, 7, 9, 4, 4, 2, 1, 9, 0, 0}
	 * 		a becomes {7, 9, 1, 9, 0}
	 * 
	 * You should use Question 1, removeAtIndex, to help answer this question.
	 * 
	 */
	public void removeAll(ArrayList<Integer> items) {
		//to be completed
	}
	
	/**
	 * QUESTION 3. Worth 10 marks
	 * @param item
	 * Add item to the middle of the MyArrayList a.
	 * 
	 * If the initial number of items in a is odd,
	 * place item to the right of the middle number
	 * 
	 * For example,
	 * given that INC_SIZE = 5,
	 * 
	 * a = {4, 5, 2, 5, 6}, item = 7
	 * 		becomes {4, 5, 2, 7, 5, 6, 0, 0, 0, 0}
	 * 
	 * a = {5, 4, 2, 9, 0}, item = 3
	 * 		becomes {5, 4, 3, 2, 9}
	 * 
	 */
	public void addToMiddle(int item) {
		//to be completed
	}
	
	/**
	 * QUESTION 4. Worth 10 marks
	 * @param toAdd
	 * Add all of the items in toAdd to the end of a if it is not already in a
	 * 
	 * For example,
	 * a = {1, 3, 8, 4, 9}, toAdd = {4, 5, 5, 1, 7}
	 * 		a becomes {1, 3, 8, 4, 9, 5, 7}
	 * 
	 */
	public void addToEndIfNotThere(int[] toAdd) {
		//to be completed
	}
	
	/**
	 * QUESTION 5. Worth 10 marks
	 * @param toAdd
	 * Add all items in toAdd to a so that a remains in ascending order
	 * 
	 * Assume both a and toAdd are already in ascending order
	 * Assume all items in toAdd are >= the first item in a,
	 * and <= the last item in a
	 * 
	 * For example,
	 * a = {1, 3, 4, 5, 5, 7, 9}, toAdd = {2, 3, 5}
	 * 		a = {1, 2, 3, 3, 4, 5, 5, 5, 7, 9}
	 *
	 */
	public void ascendingAddEasier(ArrayList<Integer> toAdd) {
		//to be completed
	}

	
	/**
	 * QUESTION 6. Worth 10 marks
	 * HARDER VERSION OF QUESTION 5
	 * @param toAdd
	 * Add all items in toAdd to a so that a remains in ascending order
	 * 
	 * Assume both a and toAdd are already in ascending order
	 * 
	 * NOTE -> items in toAdd may be less than the first item in a,
	 * and more than the last item in a
	 * 
	 * For example,
	 * a = {1, 3, 4, 5, 5, 7, 9}, toAdd = {2, 3, 5}
	 * 		a = {1, 2, 3, 3, 4, 5, 5, 5, 7, 9}
	 * 
	 * a = {1, 4, 5}, toAdd = {-1, 10}
	 * 		a = {-1, 1, 4, 5, 10}
	 * 
	 * 
	 */
	public void ascendingAddHarder(ArrayList<Integer> toAdd) {
		//to be completed
	}
}
package customArrayListBlank;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;

import customArrayListBlank.MyArrayList;
import customArrayListBlank.Graded;

public class MyArrayListTest {
	private static String result = "";
	private static int score = 0;
	
	@Test @Graded(description="MyArrayList:removeAtIndex(int)",marks=10)
	public void testRemoveAtIndex() {
		MyArrayList list = new MyArrayList();
		list.add(7);
		list.add(4);
		list.add(3);
		list.add(5);
		list.add(6);
		list.add(9);
		list.removeAtIndex(2);
		assertEquals("[7, 4, 5, 6, 9]", list.toString());
		list.removeAtIndex(0);
		assertEquals("[4, 5, 6, 9]", list.toString());
		list.removeAtIndex(3);
		assertEquals("[4, 5, 6]", list.toString());
		list.removeAtIndex(-1);
		assertEquals("[4, 5, 6]", list.toString());
		list.removeAtIndex(3);
		assertEquals("[4, 5, 6]", list.toString());
		score+=10; 
		result="MyArrayList:removeAtIndex(int) passed (10 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/60");
	}
	
	@Test @Graded(description="MyArrayList:removeAll(ArrayList<Integer>)",marks=10)
	public void testRemoveAll() {
		MyArrayList list = new MyArrayList();
		list.add(5);
		list.add(7);
		list.add(9);
		list.add(4);
		list.add(4);
		list.add(2);
		list.add(1);
		list.add(9);
		ArrayList<Integer> toRemove = new ArrayList<Integer>();
		toRemove.add(4);
		toRemove.add(5);
		toRemove.add(2);
		list.removeAll(toRemove);
		assertEquals("[7, 9, 1, 9]", list.toString());
		score+=10; 
		result="MyArrayList:removeAll(ArrayList<Integer>) passed (10 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/60");
	}
	
	@Test @Graded(description="MyArrayList:addToMiddle(int)",marks=10)
	public void testAddToMiddle() {
		MyArrayList list = new MyArrayList();
		list.addToMiddle(7);
		list.addToMiddle(4);
		list.addToMiddle(3);
		list.addToMiddle(5);
		list.addToMiddle(6);
		list.addToMiddle(9);
		assertEquals("[7, 3, 6, 9, 5, 4]", list.toString());
		score+=10; 
		result="MyArrayList:addToMiddle(int) passed (10 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/60");
	}
	
	@Test @Graded(description="MyArrayList:addToEndIfNotThere(int[])",marks=10)
	public void testAddToEndIfNotThere() {
		MyArrayList list = new MyArrayList();
		list.add(1);
		list.add(3);
		list.add(8);
		list.add(4);
		list.add(9);
		int[] add = new int[5];
		add[0] = 4;
		add[1] = 5;
		add[2] = 5;
		add[3] = 1;
		add[4] = 7;
		list.addToEndIfNotThere(add);
		assertEquals("[1, 3, 8, 4, 9, 5, 7]", list.toString());
		score+=10; 
		result="MyArrayList:addToEndIfNotThere(int[]) passed (10 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/60");
	}
	
	@Test @Graded(description="MyArrayList:ascendingAddEasier(ArrayList<Integer>)",marks=10)
	public void testAscendingAddEasier() {
		MyArrayList list = new MyArrayList();
		list.add(1);
		list.add(3);
		list.add(4);
		list.add(5);
		list.add(5);
		list.add(7);
		list.add(9);
		ArrayList<Integer> toAdd = new ArrayList<Integer>();
		toAdd.add(1);
		toAdd.add(2);
		toAdd.add(3);
		toAdd.add(5);
		toAdd.add(9);
		list.ascendingAddEasier(toAdd);
		assertEquals("[1, 1, 2, 3, 3, 4, 5, 5, 5, 7, 9, 9]", list.toString());
		
		score+=10; 
		result="MyArrayList:ascendingAddEasier(ArrayList<Integer>) passed (10 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/60");
	}
	
	@Test @Graded(description="MyArrayList:ascendingAddHarder(ArrayList<Integer>)",marks=10)
	public void testAscendingAddHarder() {
		MyArrayList list = new MyArrayList();
		list.add(1);
		list.add(3);
		list.add(4);
		list.add(5);
		list.add(5);
		list.add(7);
		list.add(9);
		ArrayList<Integer> toAdd = new ArrayList<Integer>();
		toAdd.add(2);
		toAdd.add(3);
		toAdd.add(5);
		list.ascendingAddHarder(toAdd);
		assertEquals("[1, 2, 3, 3, 4, 5, 5, 5, 7, 9]", list.toString());
		
		MyArrayList list2 = new MyArrayList();
		list2.add(1);
		list2.add(4);
		list2.add(5);
		
		toAdd.clear();
		toAdd.add(-2);
		toAdd.add(-1);
		toAdd.add(10);
		toAdd.add(18);
		list2.ascendingAddHarder(toAdd);
		assertEquals("[-2, -1, 1, 4, 5, 10, 18]", list2.toString());
		score+=10; 
		result="MyArrayList:ascendingAddHarder(ArrayList<Integer>) passed (10 marks)"; 
		
		System.out.println(result);
		System.out.println("Total: "+score+"/60");
	}
}
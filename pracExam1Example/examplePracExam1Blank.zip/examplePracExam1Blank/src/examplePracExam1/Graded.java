package examplePracExam1;
public @interface Graded {
	String description();
	int marks();
}

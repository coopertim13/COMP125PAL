package examplePracExam1;
//DO NOT CHANGE ANY METHOD HEADER

//QUESTION 1
class Waterbottle {
	private int capacity;
	private double price;
	
	public int getCapacity() {
		return capacity;
	}
	
	public double getPrice() {
		return price;
	}
	
	/**
	 * set instance variable capacity to the higher between 0 and the parameter
	 * @param c
	 */
	public void setCapacity(int c) {
		//to be completed
	}
	
	/**
	 * set instance variable price to half the value of the parameter p
	 * Ensure that price is non-negative
	 * @param p
	 */
	public void setPrice(double p) {
		//to be completed
	}
	
	/**
	 * default constructor - set instance variable capacity to 375,
	 * and price to 5.5
	 */
	public Waterbottle() {
		//to be completed
	}
	
	/**
	 * parameterized constructor: 
	 * set capacity to c and price to p
	 * @param u
	 * @param q
	 */
	public Waterbottle(int c, double p) {
		//to be completed
	}
	
	/**
	 * 
	 * Assume capacity is measured in milliliters (ml)
	 * @return total cost per ml for this waterbottle, calculated 
	 * as the price divided by the capacity
	 */
	public double totalCostPerMl() {
		return 0; //to be completed
	}
	
	/**
	 * 
	 * @param other
	 * @return 1 if calling price of calling object is more than price of parameter object
	 * -1 if calling price of calling object is less than price of parameter object
	 *  0 if calling price of calling object is same as price of parameter object
	 */
	public int compareTo(Waterbottle other) {
		return 0; //to be completed
	}
} //end of class Waterbottle

public class Questions {
	/**
	 * QUESTION 2
	 * @param n (assume n >= 0)
	 * @return the number of even digits in n
	 * HINT: n%10 gives the last digit, n/10 gives the number without the last digit
	 */
	public static int numOfEvenDigits(int n) {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 3
	 * @param arr1 (assume it is not null)
	 * @param arr2 (assume it is not null) 
	 * @return true if arr1 contains the same elements as arr2 in the same order,
	 * false otherwise
	 */
	public static boolean sameArray(int[] arr1, int[] arr2) {
		return true; //to be completed
	}
	
	/**
	 * Question 4 - ADVANCED
	 * @param arr
	 * @return an array containing all of the elements in arr repeated 5 times
	 * e.g. if arr = {1, 2} then the array
	 * to return would be {1, 2, 1, 2, 1, 2, 1, 2, 1, 2} 
	 */
	public static int[] repeatedFiveTimes(int[] arr) {
		return new int[0]; //to be completed
	}
}

package examplePracExam1;
import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class TestQuestions {
	private static int score = 0;
	private static String result = "";
	
	@Test @Graded(description="Waterbottle:setCapacity(int)", marks=15)
	public void testSetCapacityWaterbottle() {
		Waterbottle b = new Waterbottle();
		b.setCapacity(200);
		assertEquals(200, b.getCapacity());
		b.setCapacity(-12);
		assertEquals(0, b.getCapacity());
		b.setCapacity(0);
		assertEquals(0, b.getCapacity());
		score+=15;
		result+="Waterbottle:setCapacity(int) passed (15 marks)\n";
	}
	
	@Test @Graded(description="Waterbottle:setPrice(double)", marks=15)
	public void testSetPriceWaterbottle() {
		Waterbottle b = new Waterbottle();
		b.setPrice(1.5);
		assertEquals(0.75, b.getPrice(), 0.01);
		b.setPrice(-12.3);
		assertEquals(6.15, b.getPrice(), 0.01);
		b.setPrice(0);
		assertEquals(0, b.getPrice(), 0.01);
		score+=15;
		result+="Waterbottle:setPrice(double) passed (15 marks)\n";
	}

	@Test @Graded(description="Waterbottle()", marks=5)
	public void testWaterbottle() {
		Waterbottle b = new Waterbottle();
		assertEquals(375, b.getCapacity());
		assertEquals(2.75, b.getPrice(), 0.01);
		score+=5;
		result+="Waterbottle() passed (5 marks)\n";
	}
	
	@Test @Graded(description="Waterbottle(int, double)", marks=5)
	public void testWaterbottleIntDouble() {
		Waterbottle b = new Waterbottle(300, 2.5);
		assertEquals(1.25, b.getPrice(), 0.01);
		assertEquals(300, b.getCapacity());
		score+=5;
		result+="Waterbottle(int, double) passed (5 marks)\n";
	}

	//utility methods
	@Test @Graded(description="Waterbottle:totalCostPerMl()", marks=5)
	public void testTotalCostPerMl() {
		Waterbottle b = new Waterbottle(300, 4.5);
		assertEquals(0.015, b.totalCostPerMl(), 0.01);
		b = new Waterbottle(800, 4.75);
		assertEquals(0.0059375, b.totalCostPerMl(), 0.01);
		score+=5;
		result+="Waterbottle:totalCostPerMl() passed (5 marks)\n";
	}
	
	@Test @Graded(description="Waterbottle:compareTo(Waterbottle)", marks=5)
	public void testCompareToWaterbottle() {
		Waterbottle a = new Waterbottle(400, 3.95);
		Waterbottle b = new Waterbottle(348, 7.59);
		Waterbottle c = new Waterbottle(150, 2.25);
		Waterbottle d = new Waterbottle(390, 2.25);
		
		assertEquals(1, b.compareTo(a));
		assertEquals(-1, c.compareTo(a));
		assertEquals(0, c.compareTo(d));
		
		score+=5;
		result+="Waterbottle:compareTo(Waterbottle) passed (5 marks)\n";
	}
	
	@Test @Graded(description="Questions:numOfEvenDigits(int)", marks=15)
	public void testNumOfEvenDigits() {
		assertEquals(4, Questions.numOfEvenDigits(123454321));
		assertEquals(0, Questions.numOfEvenDigits(133951311));
		assertEquals(8, Questions.numOfEvenDigits(88884444));
		assertEquals(1, Questions.numOfEvenDigits(191921919));
		assertEquals(1, Questions.numOfEvenDigits(6));

		score+=15;
		result+="numOfEvenDigits(int) passed (15 marks)\n";
	}


	@Test @Graded(description="Questions:sameArray(int[], int[])", marks=15)
	public void testSameArray() {
		int[] empty = {};
		int[] gotStuff = {4,5};
		assertFalse(Questions.sameArray(empty, gotStuff));
		assertTrue(Questions.sameArray(empty, empty));
		int[] a = {-2,-4,4,2,-2,2,0,2,-2,-2};
		int[] b = {4};
		int[] c = {4};
		int[] d = {-6, -7, -6, -8};
		int[] e = {-6,-7,-6,-8};
		int[] f = {-7,-6,-6,-8};
		assertTrue(Questions.sameArray(b, c));
		assertFalse(Questions.sameArray(a, b));
		assertTrue(Questions.sameArray(d, e));
		assertFalse(Questions.sameArray(e, f));
		score+=15;
		result+="sameArray(int[],int[]) passed (15 marks)\n";
	}


	@Test @Graded(description="Questions:repeatedFiveTimes(int[])", marks=20)
	public void testRepeatedFiveTimes() {
		int[] empty = {};
		int[] arr = Questions.repeatedFiveTimes(empty);
		assertEquals("[]", Arrays.toString(arr));
		
		int[] a = {1,7,-2};
		arr = Questions.repeatedFiveTimes(a);
		assertEquals("[1, 7, -2, 1, 7, -2, 1, 7, -2, 1, 7, -2, 1, 7, -2]", Arrays.toString(arr));
		
		int[] b = {1,2};
		arr = Questions.repeatedFiveTimes(b);
		assertEquals("[1, 2, 1, 2, 1, 2, 1, 2, 1, 2]", Arrays.toString(arr));
		
		int[] c = {-3};
		arr = Questions.repeatedFiveTimes(c);
		assertEquals("[-3, -3, -3, -3, -3]", Arrays.toString(arr));
		
		int[] d = {0};
		arr = Questions.repeatedFiveTimes(d);
		assertEquals("[0, 0, 0, 0, 0]", Arrays.toString(arr));
		
		score+=20;
		result+="repeatedFiveTimes(int[]) passed (20 marks)\n";
	}

	
	@AfterClass
	public static void wrapUp() throws IOException {
	System.out.println("Score = "+score);
		System.out.println(result);
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());
		File file = new File("report"+timeStamp+".txt");
		FileWriter writer = new FileWriter(file);
		writer.write("Score = "+score+"\n");
		writer.write(result+"\n");
		writer.flush();
		writer.close();
	}
}
package examplePracExam2Blank;
//DO NOT CHANGE ANY METHOD HEADER

public class Questions {
	/**
	 * QUESTION 1
	 * @param a
	 * @param b
	 * @param c
	 * @return true if b is in the middle of (in between) a and c, false otherwise
	 */
	public static boolean bMiddleOf(int a, int b, int c) {
		return true; //to be completed
	}
	
	/**
	 * QUESTION 2
	 * @param data
	 * @return true if the last item of n is bigger than the first, false otherwise
	 * @return false if data is null or empty
	 */
	public static boolean lastBiggerThanFirst(int[] data) {
		return true; //to be completed
	}
	
	/**
	 * QUESTION 3
	 * @param n (assume n >= 0)
	 * @return the number of even digits in n
	 * HINT: n%10 gives the last digit, n/10 gives the number without the last digit
	 */
	public static int numOfEvenDigits(int n) {
		return 0; //to be completed
	}
	
	/**
	 * QUESTION 4
	 * @param arr1 (assume it is not null)
	 * @param arr2 (assume it is not null) 
	 * @return true if arr1 contains the same elements as arr2 in the same order,
	 * false otherwise
	 */
	public static boolean sameArray(int[] arr1, int[] arr2) {
		return true; //to be completed
	}
	
	/**
	 * QUESTION 5
	 * @param a
	 * @param b
	 * @return true if both a and b contain 'element' somewhere in the array,
	 * false otherwise
	 * e.g. a = {2, 3, 4} and b = {32, 4, 9} returns true (4 is in both)
	 */
	public static boolean commonElementInBoth(int[] a, int[] b, int element) {
		return true; //to be completed
	}
	
	/**
	 * Question 6 - ADVANCED
	 * @param arr
	 * @return an array containing all of the elements in arr repeated 5 times
	 * e.g. if arr = {1, 2} then the array
	 * to return would be {1, 2, 1, 2, 1, 2, 1, 2, 1, 2} 
	 */
	public static int[] repeatedFiveTimes(int[] arr) {
		return new int[0]; //to be completed
	}
	
	/**
	 * Question 7 - ADVANCED
	 * @param arr
	 * @return an array where the first item is the middle
	 * item of arr, followed by all of the items after
	 * the middle item, followed by all the items that came
	 * before the middle item
	 * 
	 * NOTE:
	 * If arr has even number of items, you should treat
	 * the middle item as the item to the right of the middle
	 * 
	 * EXAMPLES:
	 * if arr = {1, 2, 3, 4, 5} then the array
	 * to return would be {3, 4, 5, 1, 2} 
	 * 
	 * if arr = {1, 2, 3, 4, 5, 6} then the array
	 * to return would be {4, 5, 6, 1, 2, 3}
	 */
	public static int[] fromMiddleOnwards(int[] arr) {
		return new int[0]; //to be completed
	}
}

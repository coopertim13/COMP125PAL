package examplePracExam2Blank;

import static org.junit.Assert.*;
import org.junit.*;
import java.io.*;
import java.text.*;
import java.util.*;
import org.junit.rules.*;
import java.lang.reflect.*;

public class TestQuestions {
	private static int score = 0;
	private static String result = "";
	
	@Test @Graded(description="Questions:bMiddleOf(int,int,int)", marks=10)
	public void testbMiddleOf() {
		assertTrue(Questions.bMiddleOf(1,1,1));
		assertTrue(Questions.bMiddleOf(1,2,3));
		assertTrue(Questions.bMiddleOf(1,2,2));
		assertTrue(Questions.bMiddleOf(1,1,2));
		assertFalse(Questions.bMiddleOf(2,1,1));
		assertFalse(Questions.bMiddleOf(20,10,0));
		assertTrue(Questions.bMiddleOf(0,0,0));
		score+=10;
		result+="Questions:bMiddleOf(int,int,int) passed (10 marks)\n";
	}
	
	@Test @Graded(description="Questions:lastBiggerThanFirst(int[])", marks=10)
	public void testLastBiggerThanFirst() {
		assertFalse(Questions.lastBiggerThanFirst(null));
		assertFalse(Questions.lastBiggerThanFirst(new int[0]));
		int[] arr = {4};
		assertFalse(Questions.lastBiggerThanFirst(arr));
		int[] arr2 = {4, 2};
		assertFalse(Questions.lastBiggerThanFirst(arr2));
		arr2[1] = 4;
		assertFalse(Questions.lastBiggerThanFirst(arr2));
		int[] arr3 = {2,4};
		assertTrue(Questions.lastBiggerThanFirst(arr3));
		int[] arr4 = {2,9,8,6,3902,4};
		assertTrue(Questions.lastBiggerThanFirst(arr4));
		score+=10;
		result+="Questions:lastBiggerThanFirst(int[]) passed (10 marks)\n";
	}
	
	@Test @Graded(description="Questions:numOfEvenDigits(int)", marks=20)
	public void testNumOfEvenDigits() {
		assertEquals(4, Questions.numOfEvenDigits(123454321));
		assertEquals(0, Questions.numOfEvenDigits(133951311));
		assertEquals(8, Questions.numOfEvenDigits(88884444));
		assertEquals(8, Questions.numOfEvenDigits(-88884444));
		assertEquals(1, Questions.numOfEvenDigits(191921919));
		assertEquals(1, Questions.numOfEvenDigits(-191921919));
		assertEquals(1, Questions.numOfEvenDigits(6));

		score+=20;
		result+="Questions:numOfEvenDigits(int) passed (20 marks)\n";
	}
	
	@Test @Graded(description="Questions:sameArray(int[], int[])", marks=20)
	public void testSameArray() {
		int[] empty = {};
		int[] gotStuff = {4,5};
		assertFalse(Questions.sameArray(empty, gotStuff));
		assertTrue(Questions.sameArray(empty, empty));
		int[] a = {-2,-4,4,2,-2,2,0,2,-2,-2};
		int[] b = {4};
		int[] c = {4};
		int[] d = {-6, -7, -6, -8};
		int[] e = {-6,-7,-6,-8};
		int[] f = {-7,-6,-6,-8};
		assertTrue(Questions.sameArray(b, c));
		assertFalse(Questions.sameArray(a, b));
		assertTrue(Questions.sameArray(d, e));
		assertFalse(Questions.sameArray(e, f));
		score+=20;
		result+="Questions:sameArray(int[],int[]) passed (20 marks)\n";
	}
	
	@Test @Graded(description="Questions:commonElementInBoth(int[],int[],int)", marks=20)
	public void testCommonElementInBoth() {
		int[] arr1 = {1, 4, 5, -4, 3209, 329};
		int[] arr2 = {1};
		int[] arr3 = {490};
		int[] arr4 = {390, 39, 30, 2, 4, 2};
		int[] arr5 = {498, 3490, 2};
		int[] arr6 = {498, 3490, 2};
		int[] arr8 = {2, 390, 39, 30, 2, 4, 2};
		assertTrue(Questions.commonElementInBoth(arr1, arr2, 1));
		assertTrue(Questions.commonElementInBoth(arr4, arr5, 2));
		assertTrue(Questions.commonElementInBoth(arr1, arr8, 4));
		assertFalse(Questions.commonElementInBoth(arr3, arr6, 490));
		assertFalse(Questions.commonElementInBoth(arr5, arr6, 500));
		score+=20;
		result+="Questions:commonElementInBoth(int[],int[],int) passed (20 marks)\n";
	}

	@Test @Graded(description="Questions:repeatedFiveTimes(int[])", marks=10)
	public void testRepeatedFiveTimes() {
		int[] empty = {};
		int[] arr = Questions.repeatedFiveTimes(empty);
		assertEquals("[]", Arrays.toString(arr));
		
		int[] a = {1,7,-2};
		arr = Questions.repeatedFiveTimes(a);
		assertEquals("[1, 7, -2, 1, 7, -2, 1, 7, -2, 1, 7, -2, 1, 7, -2]", Arrays.toString(arr));
		
		int[] b = {1,2};
		arr = Questions.repeatedFiveTimes(b);
		assertEquals("[1, 2, 1, 2, 1, 2, 1, 2, 1, 2]", Arrays.toString(arr));
		
		int[] c = {-3};
		arr = Questions.repeatedFiveTimes(c);
		assertEquals("[-3, -3, -3, -3, -3]", Arrays.toString(arr));
		
		int[] d = {0};
		arr = Questions.repeatedFiveTimes(d);
		assertEquals("[0, 0, 0, 0, 0]", Arrays.toString(arr));
		
		score+=10;
		result+="Questions:repeatedFiveTimes(int[]) passed (10 marks)\n";
	}
	
	@Test @Graded(description="Questions:fromMiddleOnwards(int[])", marks=10)
	public void testFromMiddleOnwards() {
		assertEquals(null, Questions.fromMiddleOnwards(null));
		
		int[] empty = {};
		int[] arr = Questions.fromMiddleOnwards(empty);
		assertEquals("[]", Arrays.toString(arr));
		
		int[] a = {1,7,-2};
		arr = Questions.fromMiddleOnwards(a);
		assertEquals("[7, -2, 1]", Arrays.toString(arr));
		
		int[] b = {1,2};
		arr = Questions.fromMiddleOnwards(b);
		assertEquals("[2, 1]", Arrays.toString(arr));
		
		int[] c = {-3};
		arr = Questions.fromMiddleOnwards(c);
		assertEquals("[-3]", Arrays.toString(arr));
		
		int[] d = {3, 4, 5, 6, 7, 8};
		arr = Questions.fromMiddleOnwards(d);
		assertEquals("[6, 7, 8, 3, 4, 5]", Arrays.toString(arr));
		
		score+=10;
		result+="Questions:fromMiddleOnwards(int[]) passed (10 marks)\n";
	}

	
	@AfterClass
	public static void wrapUp() throws IOException {
	System.out.println("Score = "+score+"/100");
		System.out.println(result);
	}
}
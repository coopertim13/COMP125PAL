package examplePracExam2Blank;
public @interface Graded {
	String description();
	int marks();
}
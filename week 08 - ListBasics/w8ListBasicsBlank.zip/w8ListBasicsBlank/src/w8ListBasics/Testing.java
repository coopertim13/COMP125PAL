package w8ListBasics;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class Testing {

	@Test
	void testThreeInAList() {
		assertTrue(Questions.threeInAList().size() == 3);
	}
	
	@Test
	void testIsEmpty() {
		ArrayList<Integer> list = new ArrayList<>();
		assertTrue(Questions.isEmpty(list));
		list = null;
		assertTrue(Questions.isEmpty(list));
		list = new ArrayList<Integer>();
		list.add(4);
		assertFalse(Questions.isEmpty(list));
	}
	
	@Test
	void testFirstItemIsX() {
		ArrayList<Integer> list = new ArrayList<>();
		assertFalse(Questions.firstItemIsX(list, 28));
		list = null;
		assertFalse(Questions.firstItemIsX(list, 0));
		list = new ArrayList<Integer>();
		list.add(4);
		list.add(5);
		assertFalse(Questions.firstItemIsX(list, 5));
		assertTrue(Questions.firstItemIsX(list, 4));
	}
	
	@Test
	void testItemSecondLastPosition() {
		ArrayList<Integer> list = new ArrayList<>();
		assertEquals(-1, Questions.itemAtSecondLastPosition(list));
		list = null;
		assertEquals(-1, Questions.itemAtSecondLastPosition(list));
		list = new ArrayList<Integer>();
		list.add(4);
		assertEquals(0, Questions.itemAtSecondLastPosition(list));
		list.add(5);
		assertEquals(4, Questions.itemAtSecondLastPosition(list));
		list.add(-29);
		assertEquals(5, Questions.itemAtSecondLastPosition(list));
	}
	
	@Test
	void testItemAtX() {
		ArrayList<Integer> list = new ArrayList<>();
		assertEquals(-1, Questions.itemAtX(list, 0));
		list = null;
		assertEquals(-1, Questions.itemAtX(list, -9));
		list = new ArrayList<Integer>();
		list.add(-38);
		list.add(38);
		list.add(7192);
		list.add(-199);
		list.add(383);
		assertEquals(-1, Questions.itemAtX(list, -1));
		assertEquals(-1, Questions.itemAtX(list, 5));
		assertEquals(-1, Questions.itemAtX(list, 295));
		assertEquals(7192, Questions.itemAtX(list, 2));
		assertEquals(383, Questions.itemAtX(list, 4));
		assertEquals(-38, Questions.itemAtX(list, 0));
	}
	
	@Test
	void testContainsX() {
		ArrayList<Integer> list = new ArrayList<>();
		assertFalse(Questions.containsX(list, 281));
		list.add(-38);
		list.add(38);
		list.add(7192);
		list.add(-199);
		list.add(383);
		assertFalse(Questions.containsX(list, 3));
		assertFalse(Questions.containsX(list, 0));
		assertFalse(Questions.containsX(list, 4));
		assertFalse(Questions.containsX(list, 7193));
		assertTrue(Questions.containsX(list, 7192));
		assertTrue(Questions.containsX(list, -38));
		assertTrue(Questions.containsX(list, -199));
	}
	
	@Test
	void testMultiplyByX() {
		Questions q7 = new Questions();
		q7.list = null;
		q7.multiplyByX(219);
		assertTrue(q7.list == null);
		q7.list = new ArrayList<Integer>();
		q7.multiplyByX(29);
		assertTrue(q7.list.size() == 0);
		q7.list.add(50);
		q7.multiplyByX(0);
		assertTrue(q7.list.size() == 1 && q7.list.get(0) == 0);
		q7.list.remove(0);
		q7.list.add(24);
		q7.list.add(-29);
		q7.multiplyByX(3);
		assertTrue(q7.list.size() == 2);
		assertTrue(q7.list.get(0) == 72);
		assertTrue(q7.list.get(1) == -87);
	}
	
	@Test
	void testGetItemDoubleAL() {
		ArrayList<ArrayList<Integer>> list = new ArrayList<ArrayList<Integer>>();
		assertEquals(-1, Questions.getItemDoubleAL(list, 4, 3));
		list = null;
		assertEquals(-1, Questions.getItemDoubleAL(list, 4, 3));
		
		list = new ArrayList<ArrayList<Integer>>();
		list.add(new ArrayList<Integer>());
		list.get(0).add(40);
		assertEquals(40, Questions.getItemDoubleAL(list, 0, 0));
		assertEquals(-1, Questions.getItemDoubleAL(list, -1, 0));
		assertEquals(-1, Questions.getItemDoubleAL(list, 1, 0));
		
		assertEquals(-1, Questions.getItemDoubleAL(list, 0, -1));
		assertEquals(-1, Questions.getItemDoubleAL(list, 0, 1));
		
		list.remove(0);
		assertEquals(-1, Questions.getItemDoubleAL(list, 4, 3));
		
		list.add(null);
		assertEquals(-1, Questions.getItemDoubleAL(list, 1, 0));
		assertEquals(-1, Questions.getItemDoubleAL(list, 0, 0));
		
		list.remove(0);
		list.add(new ArrayList<Integer>());
		assertEquals(-1, Questions.getItemDoubleAL(list, 1, 0));
		assertEquals(-1, Questions.getItemDoubleAL(list, 1, 19));
		
		list.get(0).add(4);
		list.get(0).add(5);
		list.get(0).add(6);
		list.add(new ArrayList<Integer>());
		list.get(1).add(7);
		list.get(1).add(8);
		list.get(1).add(9);
		list.add(new ArrayList<Integer>());
		list.get(2).add(10);
		list.get(2).add(11);
		list.get(2).add(12);
		assertEquals(11, Questions.getItemDoubleAL(list, 2, 1));
	}

	@Test
	void testMultiplyByXV2() {
		Questions q9 = new Questions();
		q9.bigList = null;
		q9.multiplyByXV2(19);
		assertTrue(q9.bigList == null);
		
		q9.bigList = new ArrayList<ArrayList<Integer>>();
		q9.multiplyByXV2(19);
		assertTrue(q9.bigList.size() == 0);
		
		q9.bigList.add(new ArrayList<>());
		q9.bigList.add(null);
		q9.bigList.add(new ArrayList<>());
		q9.bigList.add(new ArrayList<>());
		
		q9.bigList.get(0).add(4);
		q9.bigList.get(0).add(null);
		q9.bigList.get(0).add(5);
		
		q9.bigList.get(2).add(null);
		q9.bigList.get(2).add(null);
		q9.bigList.get(2).add(-2);
		q9.bigList.get(2).add(40);
		
		q9.multiplyByXV2(3);
		
		assertEquals(12, q9.bigList.get(0).get(0));
		assertEquals(null, q9.bigList.get(0).get(1));
		assertEquals(15, q9.bigList.get(0).get(2));
		
		assertEquals(null, q9.bigList.get(1));
		
		assertEquals(null, q9.bigList.get(2).get(0));
		assertEquals(null, q9.bigList.get(2).get(1));
		assertEquals(-6, q9.bigList.get(2).get(2));
		assertEquals(120, q9.bigList.get(2).get(3));
		
		assertEquals(0, q9.bigList.get(3).size());
	}
	
	@Test
	void testTopXWealthiest() {
		ArrayList<BankAccount> accounts = new ArrayList<>();
		assertEquals(null, Questions.topXWealthiest(accounts, 0));
		assertEquals(null, Questions.topXWealthiest(accounts, 5));
		accounts.add(new BankAccount("Cooper", 54.9));
		assertEquals(null, Questions.topXWealthiest(accounts, 5));
		assertEquals(null, Questions.topXWealthiest(accounts, 2));
		accounts = null;
		assertEquals(null, Questions.topXWealthiest(accounts, 19));
		
		accounts = new ArrayList<>();
		accounts.add(new BankAccount("Cooper", 54.9));
		accounts.add(new BankAccount("Cooper", 34.0));
		accounts.add(new BankAccount("Sam", 34.0));
		accounts.add(new BankAccount("Thomas", -299.27));
		accounts.add(null);
		accounts.add(new BankAccount("Michael", 9999999));
		accounts.add(new BankAccount("Joseph", 54.9));
		
		ArrayList<BankAccount> accounts2 = new ArrayList<>();
		accounts2.add(new BankAccount("Cooper", 34.0));
		accounts2.add(new BankAccount("Sam", 34.0));
		accounts2.add(new BankAccount("Thomas", -299.27));
		accounts2.add(null);
		
		ArrayList<BankAccount> accounts3 = new ArrayList<>();
		accounts3.add(new BankAccount("Cooper", 34));
		accounts3.add(null);
		accounts3.add(null);
		accounts3.add(null);
		
		ArrayList<String> returned = Questions.topXWealthiest(accounts, 3);
		assertEquals("Michael", returned.get(0));
		assertEquals("Cooper", returned.get(1));
		assertEquals("Joseph", returned.get(2));
		
		ArrayList<String> returned2 = Questions.topXWealthiest(accounts2, 2);
		assertEquals("Cooper", returned2.get(0));
		assertEquals("Sam", returned2.get(1));
		
		ArrayList<String> returned3 = Questions.topXWealthiest(accounts3, 2);
		assertEquals(null, returned3);
	}
}

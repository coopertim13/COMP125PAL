package w8ListBasics;

//ONLY USED FOR Q10 (HD QUESTION)
public class BankAccount {
	public String name;
	public double balance;
	
	public BankAccount(String name, double balance) {
		this.name = name;
		this.balance = balance;
	}
}
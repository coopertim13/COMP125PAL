package w8ListBasics;

import java.util.ArrayList;

public class Questions {
	public ArrayList<Integer> list;
	public ArrayList<ArrayList<Integer>> bigList;

	/**
	 * Q1
	 * @return an ArrayList of Integers that contain exactly 3 items
	 */
	public static ArrayList<Integer> threeInAList() {
		return new ArrayList<Integer>(); //to be completed
	}
	
	/**
	 * Q2
	 * @param list
	 * @return true if list is null or empty, false otherwise
	 */
	public static boolean isEmpty(ArrayList<Integer> list) {
		return false; //to be completed
	}
	
	/**
	 * Q3
	 * @param list
	 * @param x
	 * @return true if the first item in list is equal to x, false otherwise
	 * Return false if list is null or empty
	 */
	public static boolean firstItemIsX(ArrayList<Integer> list, int x) {
		return false; //to be completed
	}
	
	/**
	 * Q4
	 * @param list
	 * @return the item at the second last position in list
	 * If list contains only one item, return 0
	 * If list is null or of size 0, return -1
	 */
	public static Integer itemAtSecondLastPosition(ArrayList<Integer> list) {
		return 0; //to be completed
	}
	
	/**
	 * Q5
	 * @param list
	 * @param x
	 * @return the item at position x in list
	 * if list is null or empty or the item doesn't exist at position x, return -1
	 */
	public static Integer itemAtX(ArrayList<Integer> list, int x) {
		return 0; //to be completed
	}
	
	/**
	 * Q6
	 * @param list
	 * @param x
	 * @return true if list contains x, false otherwise
	 * You may assume list is not null
	 * Try and write your answer in one line without using a conditional statement
	 */
	public static boolean containsX(ArrayList<Integer> list, int x) {
		return false; //to be completed
	}
	
	/**
	 * Q7
	 * @param list
	 * @param x
	 * @return the original ArrayList list (instance variable 'list' belonging to this class)
	 * where all of the values have been multiplied by x
	 * Ensure not to operate on list if it is null or empty
	 */
	public void multiplyByX(int x) { //note that the method is non-static
		//to be completed
	}
	
	/**
	 * Q8
	 * @param list
	 * @param x
	 * @param y
	 * @return the item at position y in the x'th ArrayList in list
	 * Return -1 if list is null or empty, or if the x'th ArrayList in
	 * list is null, empty or doesn't exist, or if the item does not exist at position y
	 * in the ArrayList at x
	 */
	public static Integer getItemDoubleAL(ArrayList<ArrayList<Integer>> list, int x, int y) {
		return 0; //to be completed
	}
	
	/**
	 * Q9
	 * @param list
	 * @param x
	 * @return original bigList instance variable with all the values multiplied by x
	 * Do not operate on any list (or list itself) if the list is null or empty
	 * You must also ensure that the item itself is not null
	 */
	public void multiplyByXV2(int x) { //note method is non-static
		//to be completed
	}
	
	/**
	 * Q10
	 * @param accounts (HD!!!)
	 * @return an ArrayList of the names of the top x wealthiest people (in order)
	 * contained within the accounts ArrayList 
	 * 
	 * If two or more people have same bank balance and they are all within the top x
	 * wealthiest people, add them to the ArrayList in order of appearance in accounts
	 * 
	 * Return null if the accounts ArrayList is null or has < x accounts
	 * You should also return null if there are < x non-null accounts
	 * You must ensure you do not operate on a null account
	 * 
	 * For example:
	 * if account1 = "Cooper", $10
	 *    account2 = "Max", $400
	 *    account3 = "Susan", $-89
	 *    account4 = "Jonathan", $100000
	 *    and x = 2
	 * You would return ArrayList ("Jonathan", "Max")
	 * 
	 * NOTE: YOU MAY MODIFY THE ARRAYLIST PASSED
	 */
	public static ArrayList<String> topXWealthiest(ArrayList<BankAccount> accounts, int x) {
		return new ArrayList<String>(); //to be completed
	}
}

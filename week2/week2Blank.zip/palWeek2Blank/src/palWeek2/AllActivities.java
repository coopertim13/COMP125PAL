package palWeek2;

public class AllActivities {
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return true if a and b differ by two, false otherwise
	 */
	public static boolean differenceOfTwo(int a, int b) {
		return true; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @param c
	 * @return the lowest of the three integers passed
	 */
	public static int lowest(int a, int b, int c) {
		return 0; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @return the number of digits in a
	 * Assume a != 0
	 */
	public static int digitCount(int a) {
		return 0; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @return true if a is contained within sequence, false otherwise
	 * You may assume a >= 1
	 * SEQUENCE: 1, 2, 4, 7, 11, 16 ...
	 */
	public static boolean containedInSequence(int a) {
		return true; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return a to the power of b
	 * NOTE: any a to the power of 0 = 1
	 */
	public static int power(int a, int b) {
		return 0; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @return the decimal equivalent of binary number a
	 * e.g. 110011 = 51
	 * HINT: a % 10 gets last number
	 * ANOTHER HINT: use the power method you completed to help
	 */
	public static int toDecimal(int a) {
		return 0; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @return the middle letter in String a
	 * e.g. gross = o
	 * If a has even amount of letters, take middle letter to left
	 * e.g. whatup = a
	 */
	public static char middleLetter(String a) {
		return '.'; //to be completed
	}
	
	
	public static void main(String[] args) {
		System.out.println("Yo, you can test out your methods here.");

	}

}

package w4ExtensionQPAL;

public class Harder {
	
	/**QUESTION 1
	 * @param a
	 * Return the binary equivalent of a in an int[] array
	 * e.g. if a = 50, [1, 1, 0, 0, 1, 0] would be returned
	 * You may assume a >= 0
	 * You may also use Math.pow(double, double) to assist you (or not!)
	 */
	public static int[] decimalToBinary(int a) {
		return new int[0]; //to be completed
	}
	
	/*There are so many HD questions involving arrays on the Internet
	 * that I didn't bother writing more questions.
	 * 
	 * You can find a huge database of questions (with answers!) here:
	 * https://medium.com/@codingfreak/huge-collection-of-array-interview-questions-e87ac7c34e62
	 * 
	 * If you can do all/most of stage 4 questions, you should
	 * be sorted for the HD component in the upcoming module exam regardless.
	 */
}

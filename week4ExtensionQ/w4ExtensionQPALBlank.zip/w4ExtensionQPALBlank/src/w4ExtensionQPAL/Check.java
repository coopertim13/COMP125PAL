package w4ExtensionQPAL;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Check {

	@Test
	void testDecimalToBinary() {
		int[] a = {0};
		assertArrayEquals(a, Harder.decimalToBinary(0));
		
		a[0] = 1;
		assertArrayEquals(a, Harder.decimalToBinary(1));
		
		int[] b = {1, 0};
		assertArrayEquals(b, Harder.decimalToBinary(2));
		
		int[] c = {1, 1, 0, 0, 1, 0};
		assertArrayEquals(c, Harder.decimalToBinary(50));
	}

}

package w7RecursionBlank;

public class Person {
	double weight;
	boolean sex; //true for female, false for male
	
	public Person(double w, boolean s) {
		weight = w;
		sex = s;
	}
	
	//method used for Answers
	//don't edit plz
	public static String toString(Person[] people) {
		String toReturn = "";
		for(Person each: people) {
			toReturn = toReturn + each.weight + each.sex;
		}
		return toReturn;
	}
}

package w7RecursionBlank;

public class Questions {
	
	/**
	 * Q1
	 * @param arr
	 * @param i
	 * @return the sum of all items up to and including the middle item in arr
	 * If the arr has an even number of items, treat the middle item as the right-middle item
	 * Assume the first item you sum is the LAST item in the array
	 * (in other words, work from right to left)
	 */
	public static int sumUpToMiddle(int[] arr, int i) {
		return 0; //to be completed
	}
	
	/**
	 * Q2
	 * @param arr
	 * @param i
	 * @return the average of all of the items in arr.
	 * You CANNOT make a helper method that simply divides the sum
	 * of all of the items in the array
	 */
	public static double average(int[] arr, int i) {
		return 0; //to be completed
	}
	
	/**
	 * Q3
	 * @param word
	 * @return the sum of all of the ascii values for each char in word
	 * HINT: to find the ascii value of a char, CAST it to an int
	 * If you don't know what CASTING means, Google is your friend.
	 */
	public static int sumOfAsciiValues(String word) {
		return 0; //to be completed
	}
	
	/**
	 * Q4
	 * @param word
	 * @return the sum of all of the ascii values for each char in word that are
	 * UPPERCASE letters
	 * ASCII TABLE: http://sticksandstones.kstrom.com/appen.html
	 */
	public static int sumOfAsciiValuesUppercase(String word) {
		return 0; //to be completed
	}
	
	/**
	 * Q5
	 * D Question
	 * @param people
	 * @param numOfDrinks
	 * @param hoursOfDrinking
	 * @return the count of people that are under the legal blood alcohol limit of 0.05
	 * (when driving)
	 * 
	 * The formula to calculate Blood Alcohol Concentration is:
	 * 
	 * (10N - 7.5H) / 6.8M      for males
	 * (10N - 7.5H) / 5.5M      for females
	 * 
	 * where N is the number of standard drinks consumed
	 * H is hours since commencement of drinking
	 * M is weight in kg
	 * 
	 * HINT: use class Person to get sex and weight data
	 */
	public static int countUnderLimit(Person[] people, int numOfDrinks,
									  double hoursOfDrinking, int index) {
		return 0; //to be completed
	}
	
	/**
	 * Q6
	 * HD Question
	 * @param original
	 * @param originalIndex
	 * @param target
	 * @param targetIndex
	 * @param indexBad
	 * @return a new Person[] array that has all the elements in original EXCEPT
	 * for the element in original at indexBad. You may assume that the target array's length
	 * is 1 less than the original array's length
	 */
	public static Person[] returnArrayMissingOne(Person[] original, int originalIndex,
												 Person[] target, int targetIndex,
												 int indexBad) {
		return new Person[0]; //to be completed
	}
	
	/**
	 * Q7
	 * HD Question
	 * @param people
	 * @param numOfDrinks
	 * @param hoursOfDrinking
	 * @return the array of people who are OVER the BAC limit.
	 * 
	 * You can assume the people array passed contains all of the people
	 * who are being examined for their BAC
	 * 
	 * You should use the previous method, returnArrayMissingOne, to return
	 * this same array, just without the people who are under the limit
	 * 
	 * Unfortunately you will have to copy and paste the formula from countUnderLimit,
	 * unless you want to make a helper method that gets the BAC of a single Person
	 */
	public static Person[] arrayOverLimit(Person[] people, int numOfDrinks,
									  double hoursOfDrinking, int index) {
		return new Person[0]; //to be completed
	}
}

package w7RecursionBlank;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Answers {
	
	@Test
	void testSumUpToMiddle() {
		int[] a = {4, 7, 8, 9};
		assertEquals(17, Questions.sumUpToMiddle(a, a.length-1));
		
		int[] b = {0};
		assertEquals(0, Questions.sumUpToMiddle(b, b.length-1));
		
		int[] c = {4, 4};
		assertEquals(4, Questions.sumUpToMiddle(c, c.length-1));
		
		int[] d = {9, 7, 6, 5, 0};
		assertEquals(11, Questions.sumUpToMiddle(d, d.length-1));
		
		int[] e = {9, 7, -6, 5};
		assertEquals(-1, Questions.sumUpToMiddle(e, e.length-1));
	}
	
	@Test
	void testAverage() {
		int[] a = {4, 7, 8, 9};
		assertEquals(7, Questions.average(a, a.length-1));
		
		int[] b = {0};
		assertEquals(0, Questions.average(b, b.length-1));
		
		int[] c = {4, 4};
		assertEquals(4, Questions.average(c, c.length-1));
		
		int[] d = {9, 7, 6, 5};
		assertEquals(6.75, Questions.average(d, d.length-1));
		
		int[] e = {9, 7, -6, 5};
		assertEquals(3.75, Questions.average(e, e.length-1));
	}
	
	@Test
	void sumOfAsciiValues() {
		String word = "CooperIsAGreatPALFacilitator";
		assertEquals(2727, Questions.sumOfAsciiValues(word));
		
		String word2 = "CooperIsAGreatPALFacilitator!";
		assertEquals(2760, Questions.sumOfAsciiValues(word2));
		
		String word3 = "";
		assertEquals(0, Questions.sumOfAsciiValues(word3));
	}
	
	@Test
	void sumOfAsciiValuesUppercase() {
		String word = "CooperIsAGreatPALFacilitator";
		assertEquals(567, Questions.sumOfAsciiValuesUppercase(word));
		
		String word2 = "CooperIsAGreatPALFacilitator!";
		assertEquals(567, Questions.sumOfAsciiValuesUppercase(word2));
	}
	
	@Test
	void testUnderLimit() {
		Person[] people = new Person[5];
		people[0] = new Person(80.38, true);
		people[1] = new Person(70.8, true);
		people[2] = new Person(64, false);
		people[3] = new Person(70.75, true);
		people[4] = new Person(100.5, false);
		
		assertEquals(1, Questions.countUnderLimit(people, 4, 1.2, people.length-1));
	}
	
	@Test
	void returnArrayMissingOne() {
		Person[] people = new Person[5];
		people[0] = new Person(80.38, true);
		people[1] = new Person(70.8, true);
		people[2] = new Person(64, false);
		people[3] = new Person(70.75, true);
		people[4] = new Person(100.5, false);
		
		Person[] people2 = new Person[4];
		
		Person[] peopleTest = new Person[4];
		peopleTest[0] = new Person(80.38, true);
		peopleTest[1] = new Person(64, false);
		peopleTest[2] = new Person(70.75, true);
		peopleTest[3] = new Person(100.5, false);
		
		assertEquals(Person.toString(peopleTest), Person.toString(Questions.returnArrayMissingOne(people, 0, people2, 0, 1)));
		
		Person[] peopleTest2 = new Person[4];
		peopleTest2[0] = new Person(70.8, true);
		peopleTest2[1] = new Person(64, false);
		peopleTest2[2] = new Person(70.75, true);
		peopleTest2[3] = new Person(100.5, false);
		
		assertEquals(Person.toString(peopleTest2), Person.toString(Questions.returnArrayMissingOne(people, 0, people2, 0, 0)));
	
		Person[] peopleTest3 = new Person[4];
		peopleTest3[0] = new Person(80.38, true);
		peopleTest3[1] = new Person(70.8, true);
		peopleTest3[2] = new Person(64, false);
		peopleTest3[3] = new Person(70.75, true);
		
		assertEquals(Person.toString(peopleTest3), Person.toString(Questions.returnArrayMissingOne(people, 0, people2, 0, 4)));
		
		Person[] peopleTest4 = new Person[1];
		peopleTest4[0] = new Person(80.38, true);
		
		Person[] peopleTest45 = new Person[0];
		
		Person[] peopleTest5 = new Person[0];
		
		assertEquals(Person.toString(peopleTest5), Person.toString(Questions.returnArrayMissingOne(peopleTest4, 0, peopleTest45, -1, 1)));
	}
	
	@Test
	void testOverLimitArray() {
		Person[] people = new Person[5];
		people[0] = new Person(80.38, true);
		people[1] = new Person(70.8, true);
		people[2] = new Person(64, false);
		people[3] = new Person(70.75, true);
		people[4] = new Person(100.5, false);
		
		Person[] people2 = new Person[4];
		people2[0] = new Person(80.38, true);
		people2[1] = new Person(70.8, true);
		people2[2] = new Person(64, false);
		people2[3] = new Person(70.75, true);
		
		assertEquals(Person.toString(people2), Person.toString(Questions.arrayOverLimit(people, 4, 1.2, 0)));
		
		Person[] people3 = new Person[5];
		people3[0] = new Person(200, true);
		people3[1] = new Person(200, true);
		people3[2] = new Person(200, false);
		people3[3] = new Person(200, true);
		people3[4] = new Person(200, false);
		
		Person[] people4 = new Person[0];
		
		assertEquals(Person.toString(people4), Person.toString(Questions.arrayOverLimit(people3, 4, 1.2, 0)));
	
		Person[] people5 = new Person[5];
		people5[0] = new Person(80.38, true);
		people5[1] = new Person(200, true);
		people5[2] = new Person(200, false);
		people5[3] = new Person(70.75, true);
		people5[4] = new Person(100.5, false);
		
		Person[] people6 = new Person[2];
		people6[0] = new Person(80.38, true);
		people6[1] = new Person(70.75, true);
		
		assertEquals(Person.toString(people6), Person.toString(Questions.arrayOverLimit(people5, 4, 1.2, 0)));

	}
}

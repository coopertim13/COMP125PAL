package staticAndNonStatic;

public class Kangaroo {
	public double weight = 70;
	private static final boolean ALIVE = true;
	
	public Kangaroo(double w) {
		weight = w;
	}
	
	public static boolean isAlive() { //STATIC METHOD
		return ALIVE;
	}
	
	public double weightTimesN(int n) { //NON STATIC METHOD
		return weight * n;
	}
}

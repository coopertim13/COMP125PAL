package staticAndNonStatic;

public class Main {
	public static void main(String args[]) {
		
		//STATIC CALL
		boolean alive = Kangaroo.isAlive();
		/**
		 * Notice here how I call isAlive on the Kangaroo class itself.
		 * I do not need to make a new Kangaroo object, because the isAlive
		 * method belongs to the Kangaroo class.
		 */
		
		//NON STATIC CALL
		Kangaroo roo = new Kangaroo(90);
		roo.weightTimesN(4);
		/**
		 * Notice here how I had to make a new Kangaroo object roo to call
		 * weightTimesN. If I tried to do this:
		 * Kangaroo.weightTimesN(4);
		 * I would get an error that looks like this:
		 * 		Cannot make a static reference to the non-static method
		 * Because weightTimesN is non-static, the method can only be called by
		 * an instance of Kangaroo (a Kangaroo object), not the Kangaroo class itself
		 */
	}
}

package palWeek3Blank;

public class AllActivities {
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return true if a and b have the same amount of elements
	 */
	public static boolean sameSizeArray(int[] a, int[] b) {
		return true; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return true if a and b have the same elements in the same order (exact same)
	 */
	public static boolean exactSameArray(int[] a, int[] b) {
		return true; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return true if the first element of a is the same as
	 * the last element of b, false otherwise
	 * e.g. a = {2, 3, 4, 5, 6} and b = {7, 6, 5, 4, 3, 2} returns true
	 * You can assume there is at least one element in both a and b
	 */
	public static boolean firstOfASameAsLastOfB(int[] a, int[] b) {
		return true; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @param b
	 * @return true if both a and b contain 'element' somewhere in the array,
	 * false otherwise
	 * e.g. a = {2, 3, 4} and b = {32, 4, 9} returns true (4 is in both)
	 */
	public static boolean commonElementInBoth(int[] a, int[] b, int element) {
		return true; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @return an int[] that is the reverse of array a
	 */
	public static int[] reverse(int[] a) {
		return new int[0]; //to be completed
	}
	
	
	/**
	 * 
	 * @param a
	 * @return an array that contains the elements of 'a' twice
	 * e.g. {2, 3, 4, 8} returns {2, 3, 4, 8, 2, 3, 4, 8}
	 */
	public static int[] arrayTwice(int[] a) {
		return new int[0]; //to be completed
	}
	
	
	//EXTENSION QUESTION
	/**
	 * 
	 * @param a
	 * @return an array that contains the capacities of all
	 * the waterbottles within array a
	 */
	public static int[] arrayOfWaterbottleCapacity(Waterbottle[] a) {
		return new int[0]; //to be completed
	}
	
	
	//DO NOT EDIT
	//USED FOR JUNIT TESTING
	public static String toString(int[] a) {
		String toReturn = "";
		for(int i = 0; i < a.length; i++) {
			toReturn = toReturn + a[i];
		}
		return toReturn;
	}
	
	
	public static void main(String[] args) {

	}

}

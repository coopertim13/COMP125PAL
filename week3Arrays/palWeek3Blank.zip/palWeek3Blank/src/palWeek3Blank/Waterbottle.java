package palWeek3Blank;

public class Waterbottle {
	private int capacity;
	
	public void setCapacity(int cap) { //setter
		this.capacity = cap;
	}
	
	public int getCapacity() { //getter
		return this.capacity;
	}
	
	public Waterbottle() {
		setCapacity(100);
	}
	
	public Waterbottle(int capacity) {
		if(capacity < 0) {
			setCapacity(0);
		}
		else if(capacity > 100) {
			setCapacity(100);
		}
		else {
			setCapacity(capacity);
		}
	}

}

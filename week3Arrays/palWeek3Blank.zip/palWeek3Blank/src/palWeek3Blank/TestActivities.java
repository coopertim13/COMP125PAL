package palWeek3Blank;

import static org.junit.jupiter.api.Assertions.*;
import java.util.concurrent.ThreadLocalRandom;

import org.junit.jupiter.api.Test;

class TestActivities {
	
	int[] arr1 = {1, 4, 5, -4, 3209, 329};
	int[] arr2 = {1};
	int[] arr3 = {490};
	int[] arr4 = {390, 39, 30, 2, 4, 2};
	int[] arr5 = {498, 3490, 2};
	int[] arr6 = {498, 3490, 2};
	int[] arr7 = {490};
	int[] arr8 = {2, 390, 39, 30, 2, 4, 2};
	int[] arr9 = {2, 3490, 498};
	int[] arr10 = {329, 3209, -4, 5, 4, 1};
	int[] arr11 = {1, 4, 5, -4, 3209, 329, 1, 4, 5, -4, 3209, 329};
	int[] arr12 = {1, 1};

	@Test
	void testSameSizeArray() {
		assertTrue(AllActivities.sameSizeArray(arr1, arr4));
		assertTrue(AllActivities.sameSizeArray(arr2, arr3));
		assertFalse(AllActivities.sameSizeArray(arr2, arr4));
		assertFalse(AllActivities.sameSizeArray(arr1, arr5));
	}
	
	@Test
	void testExactSameArray() {
		assertTrue(AllActivities.exactSameArray(arr5, arr6));
		assertFalse(AllActivities.exactSameArray(arr2, arr3));
		assertFalse(AllActivities.exactSameArray(arr2, arr4));
		assertFalse(AllActivities.exactSameArray(arr1, arr5));
		assertTrue(AllActivities.exactSameArray(arr3, arr7));
	}
	
	@Test
	void testFirstOfASameAsLastOfB() {
		assertTrue(AllActivities.firstOfASameAsLastOfB(arr1, arr2));
		assertTrue(AllActivities.firstOfASameAsLastOfB(arr8, arr5));
		assertFalse(AllActivities.firstOfASameAsLastOfB(arr2, arr4));
		assertFalse(AllActivities.firstOfASameAsLastOfB(arr1, arr5));
		assertTrue(AllActivities.firstOfASameAsLastOfB(arr3, arr7));
	}
	
	@Test
	void testCommonElementInBoth() {
		assertTrue(AllActivities.commonElementInBoth(arr1, arr2, 1));
		assertTrue(AllActivities.commonElementInBoth(arr4, arr5, 2));
		assertTrue(AllActivities.commonElementInBoth(arr1, arr8, 4));
		assertFalse(AllActivities.commonElementInBoth(arr3, arr6, 490));
		assertFalse(AllActivities.commonElementInBoth(arr5, arr6, 500));
	}
	
	@Test
	void testReverse() {
		int[] arr = AllActivities.reverse(arr3);
		assertEquals(AllActivities.toString(arr), AllActivities.toString(arr7));
		int[] arr2 = AllActivities.reverse(arr6);
		assertEquals(AllActivities.toString(arr2), AllActivities.toString(arr9));
		int[] arr3 = AllActivities.reverse(arr1);
		assertEquals(AllActivities.toString(arr3), AllActivities.toString(arr10));
	}
	
	@Test
	void testArrayTwice() {
		int[] arr = AllActivities.arrayTwice(arr1);
		assertEquals(AllActivities.toString(arr), AllActivities.toString(arr11));
		int[] arr2 = AllActivities.arrayTwice(this.arr2);
		assertEquals(AllActivities.toString(arr2), AllActivities.toString(arr12));
	}
	
	@Test
	void testWaterbottle() {
		Waterbottle[] arr = new Waterbottle[20];
		int[] waterCapReal = new int[20];
		for(int i = 0; i < 20; i++) {
			int randomNum = ThreadLocalRandom.current().nextInt(-100, 201);
			Waterbottle wb = new Waterbottle(randomNum);
			arr[i] = wb;
			waterCapReal[i] = arr[i].getCapacity();
		}
		int[] waterCapacity = AllActivities.arrayOfWaterbottleCapacity(arr);
		assertEquals(AllActivities.toString(waterCapReal), AllActivities.toString(waterCapacity));
	}

}
